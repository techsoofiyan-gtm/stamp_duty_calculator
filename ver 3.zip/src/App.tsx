/**
 * ============================================================================
 * KANPUR STAMP DUTY & REGISTRATION FEE CALCULATOR
 * ============================================================================
 * Purpose: Estimation tool for property buyers in Kanpur Nagar & Kanpur Dehat
 * Revenue Standard: Awadh / Doab (Pucca Bigha = 22,500 sq. ft = 20 Biswa)
 * Calculator by Advocate A. Soofiyan — Kanpur
 *
 * All unit conversion constants, stamp duty rates, and registration fee rates
 * are centralized in: `src/constants/stampDutyConfig.ts`
 * ============================================================================
 */

import React, { useState, useMemo } from 'react';
import {
  CalculationInput,
  CalculationResult,
  Language,
} from './types';
import {
  convertToSqMetres,
  convertToHectares,
  STAMP_DUTY_RATES,
  REGISTRATION_FEE_RATE,
  DEFAULT_PURCHASER_EXPENSES,
} from './constants/stampDutyConfig';
import { Header } from './components/Header';
import { CalculatorForm } from './components/CalculatorForm';
import { ResultsBreakdown } from './components/ResultsBreakdown';
import { MandatoryDisclaimer } from './components/MandatoryDisclaimer';
import { PrintModal } from './components/PrintModal';
import { ReportPdfView } from './components/ReportPdfView';
import { Printer, FileText } from 'lucide-react';

// Initial realistic default inputs for Kanpur property buyers
const INITIAL_INPUT: CalculationInput = {
  propertyType: 'plot',
  localityName: 'Swaroop Nagar, Kanpur',
  areaValue: 1000,
  areaUnit: 'sq_ft',
  circleRate: 25000, // ₹25,000 per sq. m (typical Kanpur urban plot circle rate)
  declaredPrice: '',
  buyerCategory: 'male',
  registrationFeePercent: 1,
  dimensionCalcEnabled: false,
  dimensionLength: '',
  dimensionHeight: '',
  dimensionUnit: 'feet',
  includeExpenses: true,
  expenses: { ...DEFAULT_PURCHASER_EXPENSES },
};

export default function App() {
  const [language, setLanguage] = useState<Language>('en');
  const [input, setInput] = useState<CalculationInput>(INITIAL_INPUT);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [scannedViaQr, setScannedViaQr] = useState(false);

  // Check if initially opened via QR code for the standalone PDF report view
  const [isPdfMode, setIsPdfMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.location) {
      try {
        const sp = new URLSearchParams(window.location.search);
        const v = sp.get('view');
        return v === 'pdf' || v === 'report' || v === 'slip' || sp.get('report') === '1';
      } catch {
        return false;
      }
    }
    return false;
  });

  const handleInputChange = (updated: Partial<CalculationInput>) => {
    setInput((prev) => ({ ...prev, ...updated }));
  };

  const handleReset = () => {
    setInput({
      propertyType: 'plot',
      localityName: '',
      areaValue: '',
      areaUnit: 'sq_ft',
      circleRate: '',
      declaredPrice: '',
      buyerCategory: 'male',
      registrationFeePercent: 1,
      dimensionCalcEnabled: false,
      dimensionLength: '',
      dimensionHeight: '',
      dimensionUnit: 'feet',
      includeExpenses: true,
      expenses: { ...DEFAULT_PURCHASER_EXPENSES },
    });
  };

  const handleApplyPreset = (preset: 'plot' | 'agri') => {
    if (preset === 'plot') {
      setInput({
        propertyType: 'plot',
        localityName: 'Swaroop Nagar / Kalyanpur, Kanpur Nagar',
        areaValue: 1000,
        areaUnit: 'sq_ft',
        circleRate: 25000,
        declaredPrice: 2800000,
        buyerCategory: 'male',
        registrationFeePercent: 1,
        dimensionCalcEnabled: false,
        dimensionLength: '',
        dimensionHeight: '',
        dimensionUnit: 'feet',
        includeExpenses: true,
        expenses: { ...DEFAULT_PURCHASER_EXPENSES },
      });
    } else {
      setInput({
        propertyType: 'agricultural',
        localityName: 'Village Bithoor / Mandhana, Kanpur',
        areaValue: 1,
        areaUnit: 'bigha',
        circleRate: 4500000, // ₹45 Lakh / hectare (Kanpur Dehat highway-adjacent agri circle rate)
        declaredPrice: '',
        buyerCategory: 'female',
        registrationFeePercent: 1,
        dimensionCalcEnabled: false,
        dimensionLength: '',
        dimensionHeight: '',
        dimensionUnit: 'feet',
        includeExpenses: true,
        expenses: { ...DEFAULT_PURCHASER_EXPENSES },
      });
    }
  };

  // Compute live calculation results
  const results = useMemo<CalculationResult>(() => {
    let areaVal = typeof input.areaValue === 'number' && input.areaValue > 0 ? input.areaValue : 0;
    let unitUsed = input.areaUnit;

    // If dimension calculator (Length * Height) is enabled with valid inputs
    if (
      input.dimensionCalcEnabled &&
      typeof input.dimensionLength === 'number' &&
      input.dimensionLength > 0 &&
      typeof input.dimensionHeight === 'number' &&
      input.dimensionHeight > 0
    ) {
      // Area = Length * Height, always round figure to top value (Math.ceil)
      const rawArea = input.dimensionLength * input.dimensionHeight;
      areaVal = Math.ceil(rawArea);
      unitUsed = input.dimensionUnit === 'feet' ? 'sq_ft' : 'sq_m';
    }

    const circleRateVal = typeof input.circleRate === 'number' && input.circleRate > 0 ? input.circleRate : 0;
    const declaredVal = typeof input.declaredPrice === 'number' && input.declaredPrice > 0 ? input.declaredPrice : 0;

    // 1. Area conversions
    const convertedAreaSqM = convertToSqMetres(areaVal, unitUsed);
    const convertedAreaHectares = convertToHectares(convertedAreaSqM);

    // 2. Circle Rate Assessed Value (Round up to top whole rupee)
    let circleRateApplicableArea = 0;
    let circleRateUnitLabel = '';
    let circleRateValue = 0;

    if (input.propertyType === 'plot') {
      circleRateApplicableArea = convertedAreaSqM;
      circleRateUnitLabel = 'sq. m';
      circleRateValue = Math.ceil(circleRateVal * convertedAreaSqM);
    } else {
      circleRateApplicableArea = convertedAreaHectares;
      circleRateUnitLabel = 'hectare';
      circleRateValue = Math.ceil(circleRateVal * convertedAreaHectares);
    }

    // 3. Property Value (MAX of Declared Sale Price vs Circle Rate Value, rounded to top value)
    const propertyValue = Math.ceil(Math.max(declaredVal, circleRateValue));
    const valuationBasis: 'circle_rate' | 'declared_price' =
      declaredVal > circleRateValue ? 'declared_price' : 'circle_rate';

    // 4. Stamp Duty & Registration Fee Rates
    const stampDutyRate = STAMP_DUTY_RATES[input.buyerCategory];
    const regFeePercent =
      typeof input.registrationFeePercent === 'number' && input.registrationFeePercent > 0
        ? input.registrationFeePercent
        : 1;
    const registrationFeeRate = regFeePercent / 100;

    // 5. Compute Fee Amounts (Always round figure to top value / ceiling: e.g. 50.0123 -> 51)
    const stampDutyAmount = Math.ceil(propertyValue * stampDutyRate);
    const registrationFeeAmount = Math.ceil(propertyValue * registrationFeeRate);
    const governmentDues = stampDutyAmount + registrationFeeAmount;

    // 6. Purchaser Registration & Incidental Expenses
    const currentExpenses = input.expenses || DEFAULT_PURCHASER_EXPENSES;
    const typingOnline = Number(currentExpenses.typingOnline) || 0;
    const audit = Number(currentExpenses.audit) || 0;
    const advocateFee = Number(currentExpenses.advocateFee) || 0;
    const gpsPhoto = Number(currentExpenses.gpsPhoto) || 0;
    const certification = Number(currentExpenses.certification) || 0;
    const naqshaNazari = Number(currentExpenses.naqshaNazari) || 0;

    const totalExpenses = (input.includeExpenses !== false)
      ? typingOnline + audit + advocateFee + gpsPhoto + certification + naqshaNazari
      : 0;

    const grandTotal = governmentDues + totalExpenses;
    const totalPayable = grandTotal; // Grand total represents total expenses from the purchaser

    // Check if female concession applied
    const femaleConcessionApplied =
      input.buyerCategory === 'female' ||
      input.buyerCategory === 'joint_female_female' ||
      input.buyerCategory === 'joint_male_female';

    return {
      convertedAreaSqM,
      convertedAreaHectares,
      circleRateApplicableArea,
      circleRateUnitLabel,
      circleRateValue,
      declaredPrice: declaredVal,
      propertyValue,
      valuationBasis,
      stampDutyRate,
      stampDutyAmount,
      registrationFeeRate,
      registrationFeePercent: regFeePercent,
      registrationFeeAmount,
      governmentDues,
      totalExpenses,
      itemizedExpenses: {
        typingOnline,
        audit,
        advocateFee,
        gpsPhoto,
        certification,
        naqshaNazari,
      },
      grandTotal,
      totalPayable,
      femaleConcessionApplied,
    };
  }, [input]);

  // Check URL query params for ?view=pdf or ?view=report or ?report=1 or ?print=1
  React.useEffect(() => {
    try {
      const searchParams = new URLSearchParams(window.location.search);
      const view = searchParams.get('view');
      const isReportView =
        view === 'pdf' ||
        view === 'report' ||
        view === 'slip' ||
        searchParams.get('report') === '1' ||
        searchParams.get('print') === '1' ||
        searchParams.get('print') === 'true';

      if (isReportView) {
        const pt = searchParams.get('pt');
        const area = searchParams.get('area');
        const unit = searchParams.get('unit');
        const rate = searchParams.get('rate');
        const dec = searchParams.get('dec');
        const cat = searchParams.get('cat');
        const reg = searchParams.get('reg');
        const loc = searchParams.get('loc');
        const exp = searchParams.get('exp');
        const dim = searchParams.get('dim');
        const dimL = searchParams.get('dimL');
        const dimH = searchParams.get('dimH');
        const dimU = searchParams.get('dimU');

        const updated: Partial<CalculationInput> = {};
        if (pt === 'plot' || pt === 'agricultural') {
          updated.propertyType = pt;
        }
        if (area && !isNaN(Number(area))) {
          updated.areaValue = Number(area);
        }
        if (unit && ['sq_ft', 'sq_yard', 'sq_m', 'biswa', 'bigha', 'hectare'].includes(unit)) {
          updated.areaUnit = unit as any;
        }
        if (rate && !isNaN(Number(rate))) {
          updated.circleRate = Number(rate);
        }
        if (dec !== null && dec !== undefined) {
          updated.declaredPrice = dec ? Number(dec) : '';
        }
        if (cat && ['male', 'female', 'joint_male_female', 'joint_male_male', 'joint_female_female', 'company'].includes(cat)) {
          updated.buyerCategory = cat as any;
        }
        if (reg && !isNaN(Number(reg))) {
          const r = Number(reg);
          if (r >= 1 && r <= 5) updated.registrationFeePercent = r;
        }
        if (loc) {
          updated.localityName = decodeURIComponent(loc);
        }
        if (exp !== null && exp !== undefined) {
          updated.includeExpenses = exp === '1' || exp === 'true';
        }
        if (dim === '1') {
          updated.dimensionCalcEnabled = true;
          if (dimL && !isNaN(Number(dimL))) updated.dimensionLength = Number(dimL);
          if (dimH && !isNaN(Number(dimH))) updated.dimensionHeight = Number(dimH);
          if (dimU === 'feet' || dimU === 'meter') updated.dimensionUnit = dimU;
        }

        if (Object.keys(updated).length > 0) {
          setInput((prev) => ({ ...prev, ...updated }));
        }

        setScannedViaQr(true);
        setIsPdfMode(true);

        if (searchParams.get('print') === '1' || searchParams.get('print') === 'true') {
          setTimeout(() => {
            try {
              window.print();
            } catch (e) {
              // Handled by browser
            }
          }, 400);
        }
      }
    } catch {
      // ignore
    }
  }, []);

  const handleTriggerPrint = () => {
    setIsPrintModalOpen(true);
  };

  const hasValidInputs =
    typeof input.areaValue === 'number' &&
    input.areaValue > 0 &&
    typeof input.circleRate === 'number' &&
    input.circleRate > 0;

  // If opened via QR code or requested, render ONLY the dedicated Single A4 PDF Report
  if (isPdfMode) {
    return (
      <ReportPdfView
        results={results}
        input={input}
        propertyType={input.propertyType}
        language={language}
        onLanguageChange={(lang) => setLanguage(lang)}
        onOpenCalculator={() => {
          setIsPdfMode(false);
          try {
            const newUrl = new URL(window.location.href);
            newUrl.searchParams.delete('view');
            newUrl.searchParams.delete('report');
            newUrl.searchParams.delete('print');
            window.history.replaceState({}, '', newUrl.toString());
          } catch {
            // ignore
          }
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#0b0c10] text-[#f1f1f1] flex flex-col font-sans print:bg-white print:text-black">
      {/* Header */}
      <div className="print:hidden">
        <Header
          language={language}
          onLanguageToggle={(lang) => setLanguage(lang)}
          onOpenPdfReport={() => setIsPdfMode(true)}
        />
      </div>

      {/* Main Single Page Container */}
      <main id="main-content" className="flex-1 w-full max-w-4xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6 print:p-0 print:m-0 print:max-w-none">
        {/* QR Scan Alert Banner */}
        {scannedViaQr && (
          <div className="bg-amber-500/15 border border-amber-500/40 rounded-xl p-3 text-amber-200 text-xs flex items-center justify-between gap-3 shadow-md print:hidden">
            <div className="flex items-center gap-2.5">
              <span className="text-base">📱</span>
              <div>
                <span className="font-bold text-amber-300">
                  {language === 'hi' ? 'QR कोड द्वारा सत्यापित रिपोर्ट लोड की गई' : 'Verified Calculation Report Loaded via QR Scan'}
                </span>
                <p className="text-[11px] text-amber-300/80">
                  {language === 'hi'
                    ? 'यह रिपोर्ट एडवोकेट ए. सूफियान (soofiyan.com) के विधिक मानक अनुसार सीधे खोली गई है।'
                    : 'This calculation was directly loaded with the parameters embedded in the scanned QR slip.'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsPrintModalOpen(true)}
                className="px-2.5 py-1 rounded bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs cursor-pointer shadow-xs"
              >
                {language === 'hi' ? 'पर्ची देखें' : 'View Slip'}
              </button>
              <button
                type="button"
                onClick={() => setScannedViaQr(false)}
                className="text-amber-400/80 hover:text-amber-200 p-1 cursor-pointer"
                title="Dismiss"
              >
                ✕
              </button>
            </div>
          </div>
        )}

        {/* Form and Results Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Form Inputs */}
          <div className="lg:col-span-6 print:hidden">
            <CalculatorForm
              input={input}
              language={language}
              onChange={handleInputChange}
              onReset={handleReset}
              onApplyPreset={handleApplyPreset}
            />
          </div>

          {/* Right Column: Breakdown Card & Print Slip */}
          <div className="lg:col-span-6 lg:sticky lg:top-6 print:col-span-12 print:static">
            {hasValidInputs && (
              <div className="flex items-center justify-between gap-2 mb-2 px-1 print:hidden">
                <span className="text-xs font-semibold uppercase tracking-wider text-amber-400/90">
                  {language === 'hi' ? 'आगणन परिणाम' : 'Calculation Breakdown'}
                </span>
                <button
                  id="btn-print-top-quick"
                  type="button"
                  onClick={handleTriggerPrint}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 hover:text-amber-200 border border-amber-400/40 text-xs font-semibold transition-all shadow-sm active:scale-95 cursor-pointer"
                  title={language === 'hi' ? 'प्रिंट करें / PDF सहेजें' : 'Print Breakdown / Save PDF'}
                >
                  <Printer className="w-3.5 h-3.5 text-amber-400" />
                  <span>{language === 'hi' ? 'प्रिंट करें' : 'Print Slip'}</span>
                </button>
              </div>
            )}

            <ResultsBreakdown
              results={results}
              input={input}
              propertyType={input.propertyType}
              language={language}
              hasValidInputs={hasValidInputs}
              onTriggerPrint={handleTriggerPrint}
            />
          </div>
        </div>

        {/* Mandatory Disclaimer & Kanpur Revenue Standard Note */}
        <div className="print:hidden">
          <MandatoryDisclaimer language={language} />
        </div>

        {/* Footer */}
        <footer className="pt-6 pb-8 border-t border-zinc-800 text-center text-xs text-zinc-500 space-y-2 print:hidden">
          <div className="flex items-center justify-center gap-3 flex-wrap text-zinc-400">
            <span>Advocate A. Soofiyan</span>
            <span>&bull;</span>
            <span>Kanpur Bar Association</span>
            <span>&bull;</span>
            <a
              href="https://soofiyan.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-amber-400 font-bold hover:underline"
            >
              soofiyan.com
            </a>
          </div>
          <p className="text-[11px] text-zinc-600">
            Civil &amp; Revenue Court &bull; Sub-Registrar Office Complex, Kanpur Nagar &amp; Dehat
          </p>
        </footer>
      </main>

      {/* Global Interactive Print & Export Modal */}
      <PrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        results={results}
        input={input}
        propertyType={input.propertyType}
        language={language}
        onOpenDedicatedPdfView={() => {
          setIsPrintModalOpen(false);
          setIsPdfMode(true);
        }}
      />
    </div>
  );
}
