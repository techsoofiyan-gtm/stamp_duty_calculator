import React from 'react';
import { AreaUnit, Language, PropertyType } from '../types';
import {
  convertToSqMetres,
  convertToHectares,
  convertToSqFeet,
  convertToBiswa,
  convertToPuccaBigha,
  convertToAcres,
  formatNumber,
  TRANSLATIONS,
} from '../constants/stampDutyConfig';
import { ArrowRightLeft, Info, CheckCircle2 } from 'lucide-react';

interface AreaSanityCardProps {
  areaValue: number | '';
  areaUnit: AreaUnit;
  propertyType: PropertyType;
  language: Language;
}

export const AreaSanityCard: React.FC<AreaSanityCardProps> = ({
  areaValue,
  areaUnit,
  propertyType,
  language,
}) => {
  const t = TRANSLATIONS[language];
  const numArea = typeof areaValue === 'number' && areaValue > 0 ? areaValue : 0;

  if (numArea <= 0) {
    return (
      <div
        id="area-sanity-empty"
        className="mt-2.5 p-3 rounded-xl bg-[#12141c] border border-dashed border-zinc-800 text-zinc-500 text-xs flex items-center gap-2"
      >
        <Info className="w-4 h-4 text-zinc-500 shrink-0" />
        <span>
          {language === 'hi'
            ? 'क्षेत्रफल दर्ज करने पर कानपुर राजस्व मानकों के अनुसार त्वरित इकाई रूपांतरण यहाँ प्रदर्शित होगा।'
            : 'Enter an area above to view instant unit conversion under Kanpur Awadh/Doab revenue standards.'}
        </span>
      </div>
    );
  }

  const sqM = convertToSqMetres(numArea, areaUnit);
  const hectares = convertToHectares(sqM);
  const sqFt = convertToSqFeet(sqM);
  const biswa = convertToBiswa(sqM);
  const bigha = convertToPuccaBigha(sqM);
  const acres = convertToAcres(sqM);

  const isPlot = propertyType === 'plot';

  return (
    <div
      id="area-sanity-card"
      className="mt-3 p-3.5 sm:p-4 rounded-xl bg-gradient-to-r from-[#171922] to-[#12141c] border border-amber-500/30 shadow-md transition-all"
    >
      <div className="flex items-center justify-between gap-2 pb-2 mb-2.5 border-b border-zinc-800/80">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-300">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{t.convertedAreaSanity}</span>
        </div>
        <span className="text-[11px] text-zinc-400 font-mono">
          {isPlot
            ? (language === 'hi' ? 'मानक: वर्ग मीटर' : 'Plot Standard: Sq. Metre')
            : (language === 'hi' ? 'मानक: हेक्टेयर' : 'Agri Standard: Hectare')}
        </span>
      </div>

      {/* Main Converted Callout */}
      <div className="flex flex-wrap items-baseline gap-2 sm:gap-3 py-1">
        <span className="text-zinc-400 text-sm font-medium">
          =
        </span>
        <span className="text-lg sm:text-xl font-bold text-amber-300 font-mono tracking-tight">
          {formatNumber(sqM, 2)} <span className="text-xs text-amber-400/80 font-sans font-normal">sq. m</span>
        </span>
        <span className="text-zinc-600 font-bold">/</span>
        <span className="text-lg sm:text-xl font-bold text-amber-200 font-mono tracking-tight">
          {formatNumber(hectares, 4)} <span className="text-xs text-amber-400/80 font-sans font-normal">hectare</span>
        </span>
      </div>

      {/* Equivalent breakdown chips */}
      <div className="mt-3 pt-2.5 border-t border-zinc-800/80">
        <p className="text-[11px] font-medium text-zinc-400 mb-1.5 flex items-center gap-1">
          <ArrowRightLeft className="w-3 h-3 text-amber-400/70" />
          <span>{t.convertedEquivalents}</span>
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div className="bg-[#0e0f14] px-2.5 py-1.5 rounded-lg border border-zinc-800">
            <div className="text-[10px] text-zinc-400">Square Feet</div>
            <div className="font-semibold text-zinc-200 font-mono text-xs sm:text-sm">
              {formatNumber(sqFt, 1)} sq. ft
            </div>
          </div>
          <div className="bg-[#0e0f14] px-2.5 py-1.5 rounded-lg border border-zinc-800">
            <div className="text-[10px] text-zinc-400">Biswa (Kanpur)</div>
            <div className="font-semibold text-zinc-200 font-mono text-xs sm:text-sm">
              {formatNumber(biswa, 2)} Biswa
            </div>
          </div>
          <div className="bg-[#0e0f14] px-2.5 py-1.5 rounded-lg border border-zinc-800">
            <div className="text-[10px] text-zinc-400">Bigha (Pucca)</div>
            <div className="font-semibold text-zinc-200 font-mono text-xs sm:text-sm">
              {formatNumber(bigha, 3)} Bigha
            </div>
          </div>
          <div className="bg-[#0e0f14] px-2.5 py-1.5 rounded-lg border border-zinc-800">
            <div className="text-[10px] text-zinc-400">Acres</div>
            <div className="font-semibold text-zinc-200 font-mono text-xs sm:text-sm">
              {formatNumber(acres, 3)} Acre
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
