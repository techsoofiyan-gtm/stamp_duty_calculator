import React, { useState } from 'react';
import { AreaUnit, BuyerCategory, CalculationInput, DimensionUnit, Language, PropertyType, PurchaserExpenses } from '../types';
import { DEFAULT_PURCHASER_EXPENSES, TRANSLATIONS } from '../constants/stampDutyConfig';
import { AreaSanityCard } from './AreaSanityCard';
import { DimensionCalculator } from './DimensionCalculator';
import {
  Building2,
  Tractor,
  Maximize2,
  IndianRupee,
  Users,
  RotateCcw,
  Sparkles,
  HelpCircle,
  MapPin,
  Receipt,
  Percent,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface CalculatorFormProps {
  input: CalculationInput;
  language: Language;
  onChange: (updated: Partial<CalculationInput>) => void;
  onReset: () => void;
  onApplyPreset: (preset: 'plot' | 'agri') => void;
}

export const CalculatorForm: React.FC<CalculatorFormProps> = ({
  input,
  language,
  onChange,
  onReset,
  onApplyPreset,
}) => {
  const t = TRANSLATIONS[language];
  const isPlot = input.propertyType === 'plot';

  const handlePropertyTypeChange = (type: PropertyType) => {
    // If switching to Plot and current unit is hectare or acre, default to sq_ft or sq_m
    // If switching to Agri and current unit is sq_ft, default to bigha or biswa or hectare
    let newUnit = input.areaUnit;
    if (type === 'plot' && (input.areaUnit === 'hectare' || input.areaUnit === 'acre')) {
      newUnit = 'sq_ft';
    } else if (type === 'agricultural' && input.areaUnit === 'sq_ft') {
      newUnit = 'bigha';
    }

    onChange({
      propertyType: type,
      areaUnit: newUnit,
    });
  };

  return (
    <form
      id="kanpur-calculator-form"
      onSubmit={(e) => e.preventDefault()}
      className="rounded-2xl bg-[#12141c] border border-amber-500/25 p-5 sm:p-7 shadow-lg"
    >
      {/* Quick Presets & Reset Row */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 pb-4 mb-5 border-b border-zinc-800">
        <div className="flex items-center gap-1.5 text-xs text-zinc-400">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span className="font-medium text-zinc-300">{t.presetTitle}</span>
          <button
            id="btn-preset-plot"
            type="button"
            onClick={() => onApplyPreset('plot')}
            className="px-2.5 py-1 rounded bg-amber-400/10 hover:bg-amber-400/20 text-amber-300 text-[11px] font-medium border border-amber-400/25 transition-all"
          >
            {isPlot ? '✓ ' : ''}{t.presetPlot}
          </button>
          <button
            id="btn-preset-agri"
            type="button"
            onClick={() => onApplyPreset('agri')}
            className="px-2.5 py-1 rounded bg-amber-400/10 hover:bg-amber-400/20 text-amber-300 text-[11px] font-medium border border-amber-400/25 transition-all"
          >
            {!isPlot ? '✓ ' : ''}{t.presetAgri}
          </button>
        </div>

        <button
          id="btn-reset-form"
          type="button"
          onClick={onReset}
          className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 text-xs transition-colors ml-auto"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>{t.clearForm}</span>
        </button>
      </div>

      <div className="space-y-5">
        {/* 1. Property Type Selector */}
        <div>
          <label
            htmlFor="select-property-type"
            className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2"
          >
            1. {t.propertyType}
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <button
              id="btn-prop-type-plot"
              type="button"
              onClick={() => handlePropertyTypeChange('plot')}
              className={`flex items-center gap-3 p-3.5 rounded-xl border text-left transition-all ${
                isPlot
                  ? 'bg-amber-500/15 border-amber-400 text-white shadow-[0_0_15px_rgba(212,175,55,0.15)] ring-1 ring-amber-400/40'
                  : 'bg-[#181a24] border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
              }`}
            >
              <div
                className={`p-2 rounded-lg shrink-0 ${
                  isPlot ? 'bg-amber-400 text-zinc-950 font-bold' : 'bg-zinc-800 text-zinc-400'
                }`}
              >
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-semibold text-zinc-100">
                  {t.plotOption}
                </div>
                <div className="text-[11px] text-zinc-400">
                  {language === 'hi' ? 'सर्किल रेट: ₹ प्रति वर्ग मीटर' : 'Circle Rate: ₹ per Sq. Metre'}
                </div>
              </div>
            </button>

            <button
              id="btn-prop-type-agri"
              type="button"
              onClick={() => handlePropertyTypeChange('agricultural')}
              className={`flex items-center gap-3 p-3.5 rounded-xl border text-left transition-all ${
                !isPlot
                  ? 'bg-amber-500/15 border-amber-400 text-white shadow-[0_0_15px_rgba(212,175,55,0.15)] ring-1 ring-amber-400/40'
                  : 'bg-[#181a24] border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
              }`}
            >
              <div
                className={`p-2 rounded-lg shrink-0 ${
                  !isPlot ? 'bg-amber-400 text-zinc-950 font-bold' : 'bg-zinc-800 text-zinc-400'
                }`}
              >
                <Tractor className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-semibold text-zinc-100">
                  {t.agriculturalOption}
                </div>
                <div className="text-[11px] text-zinc-400">
                  {language === 'hi' ? 'सर्किल रेट: ₹ प्रति हेक्टेयर' : 'Circle Rate: ₹ per Hectare'}
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* Locality / Village / Area (Mauza / Mohalla) */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label
              htmlFor="input-locality-name"
              className="text-xs font-semibold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5"
            >
              <MapPin className="w-3.5 h-3.5 text-amber-400" />
              <span>{t.localityLabel}</span>
            </label>
            <span className="text-[10px] text-amber-400/80 font-mono">
              {language === 'hi' ? 'मौजा / वार्ड / मोहल्ला' : 'Kanpur Mauza / Ward'}
            </span>
          </div>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
              <MapPin className="w-4 h-4 text-amber-400/70" />
            </div>
            <input
              id="input-locality-name"
              type="text"
              value={input.localityName || ''}
              onChange={(e) => onChange({ localityName: e.target.value })}
              placeholder={t.localityPlaceholder}
              className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-[#161822] border border-zinc-700 text-zinc-100 placeholder:text-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-amber-400/60 focus:border-amber-400 transition-all"
            />
          </div>
          <p className="text-[11px] text-zinc-400 mt-1">
            {t.localityHelp}
          </p>
        </div>

        {/* Optional Dimension Calculator (Length * Height = Area) */}
        <DimensionCalculator
          enabled={input.dimensionCalcEnabled}
          length={input.dimensionLength}
          height={input.dimensionHeight}
          unit={input.dimensionUnit}
          language={language}
          onToggle={(enabled) => {
            onChange({ dimensionCalcEnabled: enabled });
            if (
              enabled &&
              typeof input.dimensionLength === 'number' &&
              input.dimensionLength > 0 &&
              typeof input.dimensionHeight === 'number' &&
              input.dimensionHeight > 0
            ) {
              const raw = input.dimensionLength * input.dimensionHeight;
              const rounded = Math.ceil(raw);
              onChange({
                areaValue: rounded,
                areaUnit: input.dimensionUnit === 'feet' ? 'sq_ft' : 'sq_m',
              });
            }
          }}
          onLengthChange={(length) => onChange({ dimensionLength: length })}
          onHeightChange={(height) => onChange({ dimensionHeight: height })}
          onUnitChange={(dimUnit) => onChange({ dimensionUnit: dimUnit })}
          onSyncArea={(area, unit) => onChange({ areaValue: area, areaUnit: unit })}
        />

        {/* 2 & 3. Area Value & Area Unit Input Group */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label
              htmlFor="input-area-value"
              className="text-xs font-semibold text-zinc-300 uppercase tracking-wider flex items-center gap-2 flex-wrap"
            >
              <span>2. {t.areaValue} & 3. {t.areaUnit}</span>
              {input.dimensionCalcEnabled && (
                <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-amber-400/10 text-amber-300 border border-amber-400/30 normal-case">
                  {language === 'hi' ? 'L × H से लिंक (शीर्ष पूर्णांकित)' : 'Linked to L × H (Top Rounded)'}
                </span>
              )}
            </label>
            <span className="text-[11px] text-amber-400/90 font-mono">
              Awadh/Doab Factor
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
            {/* Numeric Area Input */}
            <div className="sm:col-span-7 relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                <Maximize2 className="w-4 h-4 text-amber-400/70" />
              </div>
              <input
                id="input-area-value"
                type="number"
                min="0"
                step="any"
                value={input.areaValue}
                onChange={(e) => {
                  const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                  onChange({ areaValue: isNaN(val as number) ? '' : val });
                }}
                placeholder={t.areaPlaceholder}
                className="w-full pl-10 pr-3 py-3 rounded-xl bg-[#161822] border border-zinc-700 text-zinc-100 placeholder:text-zinc-500 text-sm sm:text-base font-mono focus:outline-none focus:ring-2 focus:ring-amber-400/60 focus:border-amber-400 transition-all"
              />
            </div>

            {/* Area Unit Dropdown */}
            <div className="sm:col-span-5">
              <select
                id="select-area-unit"
                value={input.areaUnit}
                onChange={(e) => onChange({ areaUnit: e.target.value as AreaUnit })}
                className="w-full px-3.5 py-3 rounded-xl bg-[#161822] border border-zinc-700 text-zinc-100 text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-amber-400/60 focus:border-amber-400 transition-all cursor-pointer"
              >
                <option value="sq_ft" className="bg-[#161822] text-zinc-100">{t.unitLabels.sq_ft}</option>
                <option value="sq_m" className="bg-[#161822] text-zinc-100">{t.unitLabels.sq_m}</option>
                <option value="biswa" className="bg-[#161822] text-zinc-100">{t.unitLabels.biswa}</option>
                <option value="bigha" className="bg-[#161822] text-zinc-100">{t.unitLabels.bigha}</option>
                <option value="hectare" className="bg-[#161822] text-zinc-100">{t.unitLabels.hectare}</option>
                <option value="acre" className="bg-[#161822] text-zinc-100">{t.unitLabels.acre}</option>
              </select>
            </div>
          </div>

          {/* Real-time Sanity-check Card right below Area */}
          <AreaSanityCard
            areaValue={input.areaValue}
            areaUnit={input.areaUnit}
            propertyType={input.propertyType}
            language={language}
          />
        </div>

        {/* 4. Government Circle Rate (Auto-switching unit label) */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label
              htmlFor="input-circle-rate"
              className="text-xs font-semibold text-zinc-300 uppercase tracking-wider"
            >
              4. {isPlot ? t.circleRateLabelPlot : t.circleRateLabelAgri}
            </label>
            <span className="text-[11px] px-2 py-0.5 rounded bg-amber-400/10 text-amber-300 border border-amber-400/30 font-medium">
              {isPlot ? '₹ / sq. m' : '₹ / hectare'}
            </span>
          </div>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-amber-400">
              <IndianRupee className="w-4 h-4" />
            </div>
            <input
              id="input-circle-rate"
              type="number"
              min="0"
              step="any"
              value={input.circleRate}
              onChange={(e) => {
                const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                onChange({ circleRate: isNaN(val as number) ? '' : val });
              }}
              placeholder={isPlot ? t.circleRatePlaceholderPlot : t.circleRatePlaceholderAgri}
              className="w-full pl-10 pr-24 py-3 rounded-xl bg-[#161822] border border-zinc-700 text-zinc-100 placeholder:text-zinc-500 text-sm sm:text-base font-mono focus:outline-none focus:ring-2 focus:ring-amber-400/60 focus:border-amber-400 transition-all"
            />
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-xs text-zinc-400 font-mono">
              {isPlot ? 'per sq. m' : 'per hectare'}
            </div>
          </div>
          <p className="text-[11px] text-zinc-400 mt-1 flex items-center gap-1">
            <HelpCircle className="w-3 h-3 text-amber-400/70 shrink-0" />
            <span>{isPlot ? t.circleRateHelpPlot : t.circleRateHelpAgri}</span>
          </p>
        </div>

        {/* 5. Declared / Agreement Sale Price (Optional) */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label
              htmlFor="input-declared-price"
              className="text-xs font-semibold text-zinc-300 uppercase tracking-wider flex items-center gap-1"
            >
              <span>5. {t.declaredPriceLabel}</span>
              <span className="text-zinc-500 font-normal lowercase">{t.declaredPriceOptional}</span>
            </label>
            <span className="text-[10px] text-zinc-400 font-mono">
              Sec 47A Max Rule
            </span>
          </div>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
              <IndianRupee className="w-4 h-4 text-amber-400/70" />
            </div>
            <input
              id="input-declared-price"
              type="number"
              min="0"
              step="any"
              value={input.declaredPrice}
              onChange={(e) => {
                const val = e.target.value === '' ? '' : parseFloat(e.target.value);
                onChange({ declaredPrice: isNaN(val as number) ? '' : val });
              }}
              placeholder={t.declaredPricePlaceholder}
              className="w-full pl-10 pr-3 py-3 rounded-xl bg-[#161822] border border-zinc-700 text-zinc-100 placeholder:text-zinc-500 text-sm sm:text-base font-mono focus:outline-none focus:ring-2 focus:ring-amber-400/60 focus:border-amber-400 transition-all"
            />
          </div>
          <p className="text-[11px] text-zinc-400 mt-1">
            {t.declaredPriceHelp}
          </p>
        </div>

        {/* 6. Buyer Category Dropdown */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label
              htmlFor="select-buyer-category"
              className="text-xs font-semibold text-zinc-300 uppercase tracking-wider"
            >
              6. {t.buyerCategory}
            </label>
            <span className="text-[11px] text-amber-300/80 font-mono">
              UP Stamp Slab
            </span>
          </div>

          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-amber-400">
              <Users className="w-4 h-4" />
            </div>
            <select
              id="select-buyer-category"
              value={input.buyerCategory}
              onChange={(e) => onChange({ buyerCategory: e.target.value as BuyerCategory })}
              className="w-full pl-10 pr-3.5 py-3 rounded-xl bg-[#161822] border border-zinc-700 text-zinc-100 text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-amber-400/60 focus:border-amber-400 transition-all cursor-pointer"
            >
              <option value="male" className="bg-[#161822] text-zinc-100">{t.buyerOptions.male}</option>
              <option value="female" className="bg-[#161822] text-zinc-100">{t.buyerOptions.female}</option>
              <option value="joint_male_female" className="bg-[#161822] text-zinc-100">{t.buyerOptions.joint_male_female}</option>
              <option value="joint_male_male" className="bg-[#161822] text-zinc-100">{t.buyerOptions.joint_male_male}</option>
              <option value="joint_female_female" className="bg-[#161822] text-zinc-100">{t.buyerOptions.joint_female_female}</option>
            </select>
          </div>
        </div>

        {/* 7. Registration Fee Rate Option (1% to 5%) */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label
              htmlFor="select-reg-fee-rate"
              className="text-xs font-semibold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5"
            >
              <span>7. {t.registrationFeeRateLabel}</span>
              <span className="text-zinc-500 font-normal lowercase">(1% - 5%)</span>
            </label>
            <span className="text-xs text-amber-300 font-mono font-bold">
              {input.registrationFeePercent ?? 1}% Selected
            </span>
          </div>

          <div className="space-y-2">
            {/* Quick-select rate pills: 1%, 2%, 3%, 4%, 5% */}
            <div className="grid grid-cols-5 gap-2">
              {[1, 2, 3, 4, 5].map((pct) => {
                const isSelected = (input.registrationFeePercent ?? 1) === pct;
                return (
                  <button
                    key={pct}
                    id={`btn-reg-fee-${pct}`}
                    type="button"
                    onClick={() => onChange({ registrationFeePercent: pct })}
                    className={`py-2 px-1 rounded-xl text-center font-mono transition-all cursor-pointer border ${
                      isSelected
                        ? 'bg-amber-400 text-zinc-950 font-black border-amber-300 shadow-md shadow-amber-400/25 ring-1 ring-amber-300 scale-[1.02]'
                        : 'bg-[#161822] text-zinc-300 font-bold border-zinc-700 hover:border-zinc-500 hover:bg-[#1c1f2c]'
                    }`}
                  >
                    <div className="text-sm">{pct}%</div>
                    <div className={`text-[9px] font-sans ${isSelected ? 'text-zinc-950 font-semibold' : 'text-zinc-500'}`}>
                      {pct === 1 ? (language === 'hi' ? 'मानक' : 'Default') : ''}
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="flex items-center justify-between text-[11px] text-zinc-400">
              <p className="flex items-center gap-1">
                <HelpCircle className="w-3 h-3 text-amber-400/70 shrink-0" />
                <span>{t.registrationFeeRateHelp}</span>
              </p>
              {(input.registrationFeePercent ?? 1) !== 1 && (
                <button
                  type="button"
                  onClick={() => onChange({ registrationFeePercent: 1 })}
                  className="text-amber-400 hover:text-amber-300 underline text-[10px] ml-2 shrink-0 cursor-pointer"
                >
                  {language === 'hi' ? '1% रीसेट करें' : 'Reset to 1%'}
                </button>
              )}
            </div>
          </div>
        </div>

        {/* 8. Purchaser's Incidental & Registration Expenses */}
        <div className="rounded-xl border border-amber-500/30 bg-[#161822] p-4">
          <div className="flex items-center justify-between gap-2 pb-3 border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-amber-400/10 text-amber-400">
                <Receipt className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-semibold text-zinc-200 uppercase tracking-wider">
                  8. {t.expensesSectionTitle}
                </h4>
                <p className="text-[11px] text-zinc-400 hidden sm:block">
                  {t.expensesSectionSubtitle}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-amber-400/15 text-amber-300 border border-amber-400/30">
                ₹{((input.expenses?.typingOnline ?? 1200) +
                  (input.expenses?.audit ?? 1000) +
                  (input.expenses?.advocateFee ?? 1500) +
                  (input.expenses?.gpsPhoto ?? 100) +
                  (input.expenses?.certification ?? 1500) +
                  (input.expenses?.naqshaNazari ?? 1000)).toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          <div className="pt-3 space-y-3">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-zinc-300 select-none">
                <input
                  type="checkbox"
                  checked={input.includeExpenses !== false}
                  onChange={(e) => onChange({ includeExpenses: e.target.checked })}
                  className="rounded border-zinc-700 bg-zinc-900 text-amber-500 focus:ring-amber-400 focus:ring-offset-zinc-900 h-4 w-4"
                />
                <span>{t.expensesIncludeCheckbox}</span>
              </label>

              <button
                type="button"
                onClick={() => onChange({ expenses: { ...DEFAULT_PURCHASER_EXPENSES } })}
                className="text-[11px] text-amber-400/80 hover:text-amber-300 underline"
              >
                {language === 'hi' ? 'मानक दरें बहाल करें' : 'Restore Defaults'}
              </button>
            </div>

            {input.includeExpenses !== false && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                {/* 1. Type, online etc */}
                <div className="p-2.5 rounded-lg bg-[#11131a] border border-zinc-800 flex items-center justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-medium text-zinc-200 truncate">
                      {t.expTypingOnline}
                    </div>
                    <div className="text-[10px] text-zinc-400 truncate">
                      {t.expTypingOnlineDesc}
                    </div>
                  </div>
                  <div className="relative w-24 shrink-0">
                    <span className="absolute inset-y-0 left-0 pl-2 flex items-center pointer-events-none text-zinc-400 text-xs">
                      ₹
                    </span>
                    <input
                      type="number"
                      min="0"
                      value={input.expenses?.typingOnline ?? 1200}
                      onChange={(e) =>
                        onChange({
                          expenses: {
                            ...(input.expenses || DEFAULT_PURCHASER_EXPENSES),
                            typingOnline: parseFloat(e.target.value) || 0,
                          },
                        })
                      }
                      className="w-full pl-5 pr-2 py-1 text-right text-xs font-mono font-semibold bg-zinc-900/80 border border-zinc-700 rounded text-amber-300 focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                {/* 2. Audit */}
                <div className="p-2.5 rounded-lg bg-[#11131a] border border-zinc-800 flex items-center justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-medium text-zinc-200 truncate">
                      {t.expAudit}
                    </div>
                    <div className="text-[10px] text-zinc-400 truncate">
                      {t.expAuditDesc}
                    </div>
                  </div>
                  <div className="relative w-24 shrink-0">
                    <span className="absolute inset-y-0 left-0 pl-2 flex items-center pointer-events-none text-zinc-400 text-xs">
                      ₹
                    </span>
                    <input
                      type="number"
                      min="0"
                      value={input.expenses?.audit ?? 1000}
                      onChange={(e) =>
                        onChange({
                          expenses: {
                            ...(input.expenses || DEFAULT_PURCHASER_EXPENSES),
                            audit: parseFloat(e.target.value) || 0,
                          },
                        })
                      }
                      className="w-full pl-5 pr-2 py-1 text-right text-xs font-mono font-semibold bg-zinc-900/80 border border-zinc-700 rounded text-amber-300 focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                {/* 3. Advocate's fee */}
                <div className="p-2.5 rounded-lg bg-[#11131a] border border-zinc-800 flex items-center justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-medium text-zinc-200 truncate">
                      {t.expAdvocateFee}
                    </div>
                    <div className="text-[10px] text-zinc-400 truncate">
                      {t.expAdvocateFeeDesc}
                    </div>
                  </div>
                  <div className="relative w-24 shrink-0">
                    <span className="absolute inset-y-0 left-0 pl-2 flex items-center pointer-events-none text-zinc-400 text-xs">
                      ₹
                    </span>
                    <input
                      type="number"
                      min="0"
                      value={input.expenses?.advocateFee ?? 1500}
                      onChange={(e) =>
                        onChange({
                          expenses: {
                            ...(input.expenses || DEFAULT_PURCHASER_EXPENSES),
                            advocateFee: parseFloat(e.target.value) || 0,
                          },
                        })
                      }
                      className="w-full pl-5 pr-2 py-1 text-right text-xs font-mono font-semibold bg-zinc-900/80 border border-zinc-700 rounded text-amber-300 focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                {/* 4. GPS photo */}
                <div className="p-2.5 rounded-lg bg-[#11131a] border border-zinc-800 flex items-center justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-medium text-zinc-200 truncate">
                      {t.expGpsPhoto}
                    </div>
                    <div className="text-[10px] text-zinc-400 truncate">
                      {t.expGpsPhotoDesc}
                    </div>
                  </div>
                  <div className="relative w-24 shrink-0">
                    <span className="absolute inset-y-0 left-0 pl-2 flex items-center pointer-events-none text-zinc-400 text-xs">
                      ₹
                    </span>
                    <input
                      type="number"
                      min="0"
                      value={input.expenses?.gpsPhoto ?? 100}
                      onChange={(e) =>
                        onChange({
                          expenses: {
                            ...(input.expenses || DEFAULT_PURCHASER_EXPENSES),
                            gpsPhoto: parseFloat(e.target.value) || 0,
                          },
                        })
                      }
                      className="w-full pl-5 pr-2 py-1 text-right text-xs font-mono font-semibold bg-zinc-900/80 border border-zinc-700 rounded text-amber-300 focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                {/* 5. Certification */}
                <div className="p-2.5 rounded-lg bg-[#11131a] border border-zinc-800 flex items-center justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-medium text-zinc-200 truncate">
                      {t.expCertification}
                    </div>
                    <div className="text-[10px] text-zinc-400 truncate">
                      {t.expCertificationDesc}
                    </div>
                  </div>
                  <div className="relative w-24 shrink-0">
                    <span className="absolute inset-y-0 left-0 pl-2 flex items-center pointer-events-none text-zinc-400 text-xs">
                      ₹
                    </span>
                    <input
                      type="number"
                      min="0"
                      value={input.expenses?.certification ?? 1500}
                      onChange={(e) =>
                        onChange({
                          expenses: {
                            ...(input.expenses || DEFAULT_PURCHASER_EXPENSES),
                            certification: parseFloat(e.target.value) || 0,
                          },
                        })
                      }
                      className="w-full pl-5 pr-2 py-1 text-right text-xs font-mono font-semibold bg-zinc-900/80 border border-zinc-700 rounded text-amber-300 focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>

                {/* 6. Naqsha Nazari */}
                <div className="p-2.5 rounded-lg bg-[#11131a] border border-zinc-800 flex items-center justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-medium text-zinc-200 truncate">
                      {t.expNaqshaNazari}
                    </div>
                    <div className="text-[10px] text-zinc-400 truncate">
                      {t.expNaqshaNazariDesc}
                    </div>
                  </div>
                  <div className="relative w-24 shrink-0">
                    <span className="absolute inset-y-0 left-0 pl-2 flex items-center pointer-events-none text-zinc-400 text-xs">
                      ₹
                    </span>
                    <input
                      type="number"
                      min="0"
                      value={input.expenses?.naqshaNazari ?? 1000}
                      onChange={(e) =>
                        onChange({
                          expenses: {
                            ...(input.expenses || DEFAULT_PURCHASER_EXPENSES),
                            naqshaNazari: parseFloat(e.target.value) || 0,
                          },
                        })
                      }
                      className="w-full pl-5 pr-2 py-1 text-right text-xs font-mono font-semibold bg-zinc-900/80 border border-zinc-700 rounded text-amber-300 focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </form>
  );
};
