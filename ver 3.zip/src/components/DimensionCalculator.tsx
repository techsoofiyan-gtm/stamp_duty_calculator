import React from 'react';
import { DimensionUnit, AreaUnit, Language } from '../types';
import { TRANSLATIONS, formatNumber } from '../constants/stampDutyConfig';
import { Ruler, ArrowUpRight, Calculator, Sparkles, Check } from 'lucide-react';

interface DimensionCalculatorProps {
  enabled: boolean;
  length: number | '';
  height: number | '';
  unit: DimensionUnit;
  language: Language;
  onToggle: (enabled: boolean) => void;
  onLengthChange: (length: number | '') => void;
  onHeightChange: (height: number | '') => void;
  onUnitChange: (unit: DimensionUnit) => void;
  onSyncArea: (area: number, unit: AreaUnit) => void;
}

export const DimensionCalculator: React.FC<DimensionCalculatorProps> = ({
  enabled,
  length,
  height,
  unit,
  language,
  onToggle,
  onLengthChange,
  onHeightChange,
  onUnitChange,
  onSyncArea,
}) => {
  const t = TRANSLATIONS[language];

  const numLength = typeof length === 'number' && length > 0 ? length : 0;
  const numHeight = typeof height === 'number' && height > 0 ? height : 0;
  const hasDimensions = numLength > 0 && numHeight > 0;

  const rawArea = hasDimensions ? numLength * numHeight : 0;
  // Always round figure to the top value (Math.ceil: 50.67 -> 51, 50.0123 -> 51)
  const topRoundedArea = Math.ceil(rawArea);
  const targetAreaUnit: AreaUnit = unit === 'feet' ? 'sq_ft' : 'sq_m';
  const unitSuffix = unit === 'feet' ? 'ft' : 'm';
  const areaUnitLabel = unit === 'feet' ? (language === 'hi' ? 'वर्ग फुट (sq. ft)' : 'sq. ft') : (language === 'hi' ? 'वर्ग मीटर (sq. m)' : 'sq. m');

  // Trigger sync to parent form when dimensions change
  const handleLengthInput = (valStr: string) => {
    const val = valStr === '' ? '' : parseFloat(valStr);
    const parsed = isNaN(val as number) ? '' : (val as number);
    onLengthChange(parsed);

    if (typeof parsed === 'number' && parsed > 0 && numHeight > 0) {
      const raw = parsed * numHeight;
      const rounded = Math.ceil(raw);
      onSyncArea(rounded, targetAreaUnit);
    }
  };

  const handleHeightInput = (valStr: string) => {
    const val = valStr === '' ? '' : parseFloat(valStr);
    const parsed = isNaN(val as number) ? '' : (val as number);
    onHeightChange(parsed);

    if (numLength > 0 && typeof parsed === 'number' && parsed > 0) {
      const raw = numLength * parsed;
      const rounded = Math.ceil(raw);
      onSyncArea(rounded, targetAreaUnit);
    }
  };

  const handleUnitSwitch = (newUnit: DimensionUnit) => {
    onUnitChange(newUnit);
    if (hasDimensions) {
      const newAreaUnit: AreaUnit = newUnit === 'feet' ? 'sq_ft' : 'sq_m';
      onSyncArea(topRoundedArea, newAreaUnit);
    }
  };

  const handleCheckboxToggle = (checked: boolean) => {
    onToggle(checked);
    if (checked && hasDimensions) {
      onSyncArea(topRoundedArea, targetAreaUnit);
    }
  };

  return (
    <div
      id="dimension-calculator-section"
      className={`rounded-2xl border transition-all duration-200 ${
        enabled
          ? 'bg-[#151722] border-amber-400/50 shadow-[0_4px_20px_rgba(212,175,55,0.12)] p-4 sm:p-5'
          : 'bg-[#12141c] border-zinc-800/90 hover:border-zinc-700/80 p-3.5 sm:p-4'
      }`}
    >
      {/* Checkbox row */}
      <div className="flex items-start justify-between gap-3">
        <label
          htmlFor="checkbox-dimension-calc"
          className="flex items-start gap-3 cursor-pointer select-none group flex-1"
        >
          <div className="relative flex items-center justify-center mt-0.5">
            <input
              id="checkbox-dimension-calc"
              type="checkbox"
              checked={enabled}
              onChange={(e) => handleCheckboxToggle(e.target.checked)}
              className="w-5 h-5 rounded-md border-2 border-zinc-600 bg-zinc-900 text-amber-400 focus:ring-amber-400 focus:ring-offset-0 focus:ring-2 accent-amber-400 cursor-pointer transition-all"
            />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm font-semibold text-zinc-100 group-hover:text-amber-300 transition-colors flex items-center gap-1.5">
                <Calculator className="w-4 h-4 text-amber-400" />
                {t.dimensionCheckboxLabel}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-amber-400/10 text-amber-300 border border-amber-400/30">
                L × H = Area
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-0.5 leading-normal">
              {t.dimensionCheckboxSubtext}
            </p>
          </div>
        </label>
      </div>

      {/* Expanded Dimension Input Controls */}
      {enabled && (
        <div className="mt-4 pt-4 border-t border-zinc-800/80 space-y-4">
          {/* Dimension Unit Toggle: Feet vs Meter */}
          <div>
            <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-2">
              {t.dimensionUnitLabel}
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                id="btn-dim-unit-feet"
                type="button"
                onClick={() => handleUnitSwitch('feet')}
                className={`flex items-center justify-center gap-2 py-2 px-3 rounded-xl border text-xs sm:text-sm font-medium transition-all ${
                  unit === 'feet'
                    ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-sm ring-1 ring-amber-400/30 font-semibold'
                    : 'bg-[#181a24] border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                }`}
              >
                <Ruler className="w-3.5 h-3.5" />
                <span>{t.dimensionUnitFeet}</span>
              </button>

              <button
                id="btn-dim-unit-meter"
                type="button"
                onClick={() => handleUnitSwitch('meter')}
                className={`flex items-center justify-center gap-2 py-2 px-3 rounded-xl border text-xs sm:text-sm font-medium transition-all ${
                  unit === 'meter'
                    ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-sm ring-1 ring-amber-400/30 font-semibold'
                    : 'bg-[#181a24] border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                }`}
              >
                <Ruler className="w-3.5 h-3.5" />
                <span>{t.dimensionUnitMeter}</span>
              </button>
            </div>
          </div>

          {/* Length & Height Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Length Input */}
            <div>
              <label
                htmlFor="input-dim-length"
                className="block text-xs font-semibold text-zinc-300 mb-1.5"
              >
                {t.dimensionLengthLabel} ({unitSuffix})
              </label>
              <div className="relative">
                <input
                  id="input-dim-length"
                  type="number"
                  min="0"
                  step="any"
                  value={length}
                  onChange={(e) => handleLengthInput(e.target.value)}
                  placeholder={t.dimensionLengthPlaceholder}
                  className="w-full pl-3.5 pr-12 py-2.5 rounded-xl bg-[#10121a] border border-zinc-700 text-zinc-100 placeholder:text-zinc-500 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-amber-400/60 focus:border-amber-400 transition-all"
                />
                <span className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-xs text-amber-400/80 font-mono font-bold">
                  {unitSuffix}
                </span>
              </div>
            </div>

            {/* Height / Width Input */}
            <div>
              <label
                htmlFor="input-dim-height"
                className="block text-xs font-semibold text-zinc-300 mb-1.5"
              >
                {t.dimensionHeightLabel} ({unitSuffix})
              </label>
              <div className="relative">
                <input
                  id="input-dim-height"
                  type="number"
                  min="0"
                  step="any"
                  value={height}
                  onChange={(e) => handleHeightInput(e.target.value)}
                  placeholder={t.dimensionHeightPlaceholder}
                  className="w-full pl-3.5 pr-12 py-2.5 rounded-xl bg-[#10121a] border border-zinc-700 text-zinc-100 placeholder:text-zinc-500 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-amber-400/60 focus:border-amber-400 transition-all"
                />
                <span className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-xs text-amber-400/80 font-mono font-bold">
                  {unitSuffix}
                </span>
              </div>
            </div>
          </div>

          {/* Real-time Equation & Ceiling Rounding Feedback Banner */}
          <div
            id="dim-calc-feedback-box"
            className="p-3 sm:p-3.5 rounded-xl bg-[#0e1017] border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
          >
            <div>
              <div className="flex items-center gap-1.5 text-zinc-300 font-medium">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>{t.dimensionResultFormula}:</span>
              </div>
              {hasDimensions ? (
                <div className="mt-1 font-mono text-zinc-200 flex items-baseline gap-2 flex-wrap">
                  <span className="text-zinc-400">
                    {numLength} {unitSuffix} × {numHeight} {unitSuffix} =
                  </span>
                  <span className="text-amber-300 font-bold">
                    {formatNumber(rawArea, 4)} {unitSuffix === 'ft' ? 'sq. ft' : 'sq. m'}
                  </span>
                  {rawArea !== topRoundedArea && (
                    <span className="text-emerald-400 font-bold flex items-center gap-1">
                      → {topRoundedArea} {unitSuffix === 'ft' ? 'sq. ft' : 'sq. m'}
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950/60 text-emerald-300 border border-emerald-500/40 font-sans font-medium">
                        {language === 'hi' ? 'शीर्ष मान' : 'Top Value'}
                      </span>
                    </span>
                  )}
                </div>
              ) : (
                <p className="text-zinc-500 text-[11px] mt-0.5">
                  {language === 'hi'
                    ? 'लंबाई और ऊंचाई दर्ज करने पर क्षेत्रफल स्वतः यहां संगणित होगा'
                    : 'Enter length and height above to compute the area'}
                </p>
              )}
            </div>

            {hasDimensions && (
              <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
                <div className="px-2.5 py-1 rounded-lg bg-amber-400/10 border border-amber-400/30 text-amber-300 text-right">
                  <div className="text-[10px] uppercase font-bold tracking-wider text-amber-400/80">
                    {language === 'hi' ? 'लागू क्षेत्रफल' : 'Applied Area'}
                  </div>
                  <div className="text-base font-bold font-mono text-zinc-100">
                    {topRoundedArea} <span className="text-xs font-normal text-amber-300">{areaUnitLabel}</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Rounding rule note banner */}
          <div className="text-[11px] text-amber-300/80 flex items-center gap-1.5 px-1">
            <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>{t.topRoundingBadge}</span>
          </div>
        </div>
      )}
    </div>
  );
};
