import React from 'react';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants/stampDutyConfig';
import { LanguageToggle } from './LanguageToggle';
import { Scale, Landmark, MapPin } from 'lucide-react';

interface HeaderProps {
  language: Language;
  onLanguageToggle: (lang: Language) => void;
  onOpenPdfReport?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onLanguageToggle,
  onOpenPdfReport,
}) => {
  const t = TRANSLATIONS[language];

  return (
    <header id="app-header" className="w-full pt-6 pb-4 sm:py-8 border-b border-amber-500/20 bg-gradient-to-b from-[#14161f] via-[#0d0e14] to-[#0b0c10]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          
          {/* Logo & Identity */}
          <div className="flex items-start gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400/20 via-amber-500/10 to-transparent border border-amber-400/40 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(212,175,55,0.15)]">
              <Scale className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/20">
                  <MapPin className="w-3 h-3" />
                  Kanpur Nagar & Dehat
                </span>
                <span className="text-[11px] font-medium text-zinc-400 bg-zinc-800/60 px-2 py-0.5 rounded border border-zinc-700/60">
                  {t.estimationBadge}
                </span>
                <a
                  href="https://soofiyan.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-300 bg-amber-500/15 hover:bg-amber-500/25 px-2 py-0.5 rounded border border-amber-500/30 transition-colors"
                  title="Visit soofiyan.com"
                >
                  <span>🌐 soofiyan.com</span>
                </a>
              </div>
              <h1
                id="header-title"
                className="text-xl sm:text-2xl md:text-3xl font-bold tracking-tight text-white mt-1 font-serif text-amber-100"
              >
                {t.appTitle}
              </h1>
              <p className="text-xs sm:text-sm text-zinc-400 mt-0.5 flex items-center gap-1.5 flex-wrap">
                <Landmark className="w-3.5 h-3.5 text-amber-400/80 inline shrink-0" />
                <span>{t.appSubtitle}</span>
              </p>
            </div>
          </div>

          {/* Controls & Language */}
          <div className="flex items-center self-end sm:self-center gap-2 shrink-0">
            {onOpenPdfReport && (
              <button
                type="button"
                onClick={onOpenPdfReport}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold transition cursor-pointer"
                title="Open dedicated printable Single A4 PDF report"
              >
                <span>📄 PDF Report</span>
              </button>
            )}
            <LanguageToggle
              currentLang={language}
              onToggle={onLanguageToggle}
            />
          </div>
        </div>

        {/* Awadh/Doab Revenue Banner */}
        <div className="mt-4 px-3.5 py-2 rounded-lg bg-amber-950/20 border border-amber-500/20 text-xs text-amber-300/90 flex items-center justify-between gap-2 flex-wrap">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
            {t.districtNotice}
          </span>
        </div>
      </div>
    </header>
  );
};
