import React from 'react';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants/stampDutyConfig';
import { Languages } from 'lucide-react';

interface LanguageToggleProps {
  currentLang: Language;
  onToggle: (lang: Language) => void;
}

export const LanguageToggle: React.FC<LanguageToggleProps> = ({
  currentLang,
  onToggle,
}) => {
  const t = TRANSLATIONS[currentLang];

  return (
    <button
      id="btn-language-toggle"
      type="button"
      onClick={() => onToggle(currentLang === 'en' ? 'hi' : 'en')}
      aria-label="Toggle language between English and Hindi"
      className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-amber-400/30 bg-[#171922] hover:bg-[#202330] hover:border-amber-400/60 text-amber-300 text-xs sm:text-sm font-medium transition-all shadow-sm active:scale-95"
    >
      <Languages className="w-4 h-4 text-amber-400" />
      <span>{t.langToggleLabel}</span>
      <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-400/10 text-amber-200 border border-amber-400/20 uppercase tracking-wider font-mono">
        {currentLang === 'en' ? 'EN' : 'HI'}
      </span>
    </button>
  );
};
