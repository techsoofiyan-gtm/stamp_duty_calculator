import React from 'react';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants/stampDutyConfig';
import { AlertTriangle, ExternalLink, Scale, ShieldCheck } from 'lucide-react';

interface MandatoryDisclaimerProps {
  language: Language;
}

export const MandatoryDisclaimer: React.FC<MandatoryDisclaimerProps> = ({
  language,
}) => {
  const t = TRANSLATIONS[language];

  return (
    <div id="mandatory-disclaimer-section" className="mt-8 space-y-4">
      {/* Prominent Mandatory Disclaimer Banner */}
      <div
        id="prominent-disclaimer-box"
        className="p-4 sm:p-5 rounded-2xl bg-[#14120e] border-2 border-amber-500/40 text-zinc-300 shadow-md"
      >
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 shrink-0 mt-0.5 border border-amber-500/30">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-amber-300 tracking-wide uppercase flex items-center gap-2">
              <span>{t.disclaimerTitle}</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-400/10 text-amber-300 border border-amber-400/20 font-mono font-normal">
                UP Stamp Act 1899
              </span>
            </h4>
            <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed font-normal">
              "{t.disclaimerText}"
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-4 text-xs">
              <a
                id="link-disclaimer-igrs"
                href="https://igrsup.gov.in"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-amber-400 hover:text-amber-300 font-semibold underline underline-offset-4 transition-colors"
              >
                <span>igrsup.gov.in</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              <span className="text-zinc-500">•</span>
              <span className="text-zinc-400">
                Kanpur Nagar / Kanpur Dehat Sub-Registrar Offices (सदर, कल्याणपुर, घाटमपुर, बिल्हौर, माती)
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Kanpur Revenue Conversion Educational Note */}
      <div
        id="kanpur-revenue-standard-card"
        className="p-4 rounded-xl bg-[#0f1016] border border-zinc-800 text-xs text-zinc-400 space-y-1.5"
      >
        <div className="flex items-center gap-2 text-zinc-200 font-semibold">
          <ShieldCheck className="w-4 h-4 text-amber-400" />
          <span>{t.kanpurRevenueNoteTitle}</span>
        </div>
        <p className="text-zinc-400 leading-relaxed">
          {t.kanpurRevenueNoteText}
        </p>
        <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px] font-mono text-amber-300/80">
          <span>1 Bigha (Pucca) = 20 Biswa</span>
          <span>•</span>
          <span>1 Biswa = 1,125 Sq. Ft</span>
          <span>•</span>
          <span>1 Sq. Metre = 10.764 Sq. Ft</span>
          <span>•</span>
          <span>1 Hectare = 10,000 Sq. M</span>
        </div>
      </div>

      {/* Mandatory Footer Line */}
      <footer id="app-footer" className="pt-6 pb-10 text-center border-t border-zinc-800/80">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#151720] border border-amber-500/20 text-xs text-amber-200">
          <Scale className="w-3.5 h-3.5 text-amber-400" />
          <span className="font-medium tracking-wide">
            {t.footerLine}
          </span>
        </div>
        <p className="text-[11px] text-zinc-400 mt-2">
          Kanpur Nagar & Kanpur Dehat Registry Estimation Tool • Awadh/Doab Land Records Standard
        </p>
      </footer>
    </div>
  );
};
