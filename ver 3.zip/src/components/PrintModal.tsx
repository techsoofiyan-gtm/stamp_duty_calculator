import React, { useState, useEffect, useMemo } from 'react';
import { CalculationInput, CalculationResult, Language, PropertyType } from '../types';
import { TRANSLATIONS } from '../constants/stampDutyConfig';
import { PrintableCalculationSlip } from './PrintableCalculationSlip';
import { generatePrintableSlipHtml } from '../utils/printHtmlGenerator';
import { printHtmlViaHiddenIframe, downloadSlipAsHtml } from '../utils/printHelper';
import { buildReportShareUrl, generateQrDataUrl } from '../utils/qrHelper';
import {
  Printer,
  ExternalLink,
  Download,
  X,
  Copy,
  Check,
  Info,
  Scale,
  QrCode,
  Globe,
} from 'lucide-react';

interface PrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  results: CalculationResult;
  input: CalculationInput;
  propertyType: PropertyType;
  language: Language;
  onOpenDedicatedPdfView?: () => void;
}

export const PrintModal: React.FC<PrintModalProps> = ({
  isOpen,
  onClose,
  results,
  input,
  propertyType,
  language,
  onOpenDedicatedPdfView,
}) => {
  const t = TRANSLATIONS[language];
  const [copied, setCopied] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const [printStatusNotice, setPrintStatusNotice] = useState<string | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  // Generate QR Code containing the live report URL with parameters
  useEffect(() => {
    let isMounted = true;
    const shareUrl = buildReportShareUrl(input, propertyType);
    generateQrDataUrl(shareUrl).then((url) => {
      if (isMounted) {
        setQrDataUrl(url);
      }
    });
    return () => {
      isMounted = false;
    };
  }, [input, propertyType]);

  // Pre-generate HTML slip and Blob URL for reliable opening and downloading
  const htmlContent = useMemo(() => {
    return generatePrintableSlipHtml(results, input, propertyType, language, qrDataUrl);
  }, [results, input, propertyType, language, qrDataUrl]);

  const blobUrl = useMemo(() => {
    try {
      const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
      return URL.createObjectURL(blob);
    } catch {
      return '';
    }
  }, [htmlContent]);

  // Clean up Blob URL when component unmounts or htmlContent changes
  useEffect(() => {
    return () => {
      if (blobUrl) {
        URL.revokeObjectURL(blobUrl);
      }
    };
  }, [blobUrl]);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Lock body scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSystemPrint = async () => {
    setIsPrinting(true);
    setPrintStatusNotice(language === 'hi' ? 'प्रिंट डायलॉग तैयार हो रहा है...' : 'Preparing print dialog...');
    try {
      const success = await printHtmlViaHiddenIframe(htmlContent);
      if (!success) {
        setPrintStatusNotice(
          language === 'hi'
            ? 'ब्राउज़र सुरक्षा प्रतिबंध: कृपया नीचे "नई विंडो में खोलें" या "पर्ची डाउनलोड" बटन चुनें।'
            : 'Print blocked by iframe policy. Please use "Open in New Tab" or "Download Slip".'
        );
      } else {
        setPrintStatusNotice(null);
      }
    } catch (err) {
      console.warn('Print error:', err);
      setPrintStatusNotice(
        language === 'hi'
          ? 'कृपया नीचे "नई विंडो में खोलें" या "पर्ची डाउनलोड" बटन का उपयोग करें।'
          : 'Please click "Open in New Tab" or "Download Slip".'
      );
    } finally {
      setIsPrinting(false);
    }
  };

  const handleDownloadHtml = () => {
    const fileName = `Kanpur_Stamp_Duty_Estimate_${propertyType}_soofiyan_com_${Date.now()}.html`;
    downloadSlipAsHtml(htmlContent, fileName);
  };

  const handleCopyText = async () => {
    const isPlot = propertyType === 'plot';

    const expensesSection = results.totalExpenses > 0 ? `
PURCHASER'S INCIDENTAL & REGISTRATION EXPENSES:
1. Typing, Online Application, E-Challan: ₹${(results.itemizedExpenses?.typingOnline ?? 1200).toLocaleString('en-IN')}
2. Revenue / Sub-Registrar Audit Verification: ₹${(results.itemizedExpenses?.audit ?? 1000).toLocaleString('en-IN')}
3. Advocate's Professional Legal Fee: ₹${(results.itemizedExpenses?.advocateFee ?? 1500).toLocaleString('en-IN')}
4. GPS Geo-Tagged Photo Capture: ₹${(results.itemizedExpenses?.gpsPhoto ?? 100).toLocaleString('en-IN')}
5. Non-Encumbrance / Bar Association Certification: ₹${(results.itemizedExpenses?.certification ?? 1500).toLocaleString('en-IN')}
6. Naqsha Nazari (Boundary & Site Layout Map): ₹${(results.itemizedExpenses?.naqshaNazari ?? 1000).toLocaleString('en-IN')}
-----------------------------------------------------
PURCHASER EXPENSES SUBTOTAL: ₹${results.totalExpenses.toLocaleString('en-IN')}
` : '';

    const textSlip = `=====================================================
ADVOCATE A. SOOFIYAN — KANPUR BAR ASSOCIATION
PROPERTY STAMP DUTY & REGISTRATION CALCULATION SLIP
PORTAL: https://soofiyan.com
=====================================================
Locality: ${input.localityName || 'Kanpur Nagar'}
Property Type: ${isPlot ? 'Residential / Commercial Plot' : 'Agricultural Land'}
Buyer Category: ${input.buyerCategory}
Entered Land Area: ${input.areaValue} ${input.areaUnit}
Converted Area: ${results.convertedAreaSqM.toFixed(2)} sq. m (${(results.convertedAreaSqM * 10.7639).toFixed(0)} sq. ft)
Applicable Circle Rate: ₹${input.circleRate} / ${isPlot ? 'sq. m' : 'hectare'}

VALUATION BENCHMARK:
- Circle Rate Assessed Value: ₹${results.circleRateValue.toLocaleString('en-IN')}
- Declared Consideration: ₹${(input.declaredPrice ? Number(input.declaredPrice) : 0).toLocaleString('en-IN')}
- Valuation Considered (Sec 47-A): ₹${results.propertyValue.toLocaleString('en-IN')}

STATUTORY DUES BREAKDOWN (GOVT):
1. Stamp Duty: ₹${results.stampDutyAmount.toLocaleString('en-IN')}
2. Registration Fee: ₹${results.registrationFeeAmount.toLocaleString('en-IN')}
Government Dues Subtotal: ₹${(results.governmentDues || (results.stampDutyAmount + results.registrationFeeAmount)).toLocaleString('en-IN')}
${expensesSection}
-----------------------------------------------------
TOTAL PAYABLE: ₹${(results.grandTotal || results.totalPayable).toLocaleString('en-IN')}
=====================================================
AUTHENTICATED VIA SOOFIYAN.COM
Official Verification: igrsup.gov.in
All dues rounded up to whole rupee (Math.ceil).
`;

    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(textSlip);
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
      }
    } catch {
      // Fallback
    }
  };

  return (
    <div
      id="print-export-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="print-modal-title"
    >
      <div className="relative w-full max-w-4xl max-h-[95vh] bg-[#12141c] border border-zinc-700/80 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-zinc-100">
        {/* Modal Header */}
        <div className="px-5 py-3.5 bg-[#161822] border-b border-zinc-800 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 id="print-modal-title" className="text-base sm:text-lg font-bold text-zinc-100 font-serif">
                  {language === 'hi' ? 'आगणन पर्ची (सिंगल A4 शीट)' : 'Single A4 Calculation Slip'}
                </h3>
                <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[10px] font-bold">
                  <Globe className="w-3 h-3" />
                  soofiyan.com
                </span>
              </div>
              <p className="text-[11px] text-zinc-400">
                {language === 'hi'
                  ? 'एकल A4 पृष्ठ रिपोर्ट (QR कोड स्कैन से रिपोर्ट लाइव देखें) • एडवोकेट ए. सूफियान'
                  : 'Guaranteed 1-Page A4 Sheet with Live QR Verification Code • Advocate A. Soofiyan'}
              </p>
            </div>
          </div>

          <button
            id="btn-close-print-modal"
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Toolbar */}
        <div className="px-5 py-3 bg-[#0e1017] border-b border-zinc-800/80 flex flex-wrap items-center justify-between gap-2.5 shrink-0 print:hidden">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Direct Print Button */}
            <button
              id="btn-modal-print-direct"
              type="button"
              onClick={handleSystemPrint}
              disabled={isPrinting}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-zinc-950 font-bold text-xs shadow-md transition-all active:scale-95 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-zinc-950" />
              <span>{isPrinting ? (language === 'hi' ? 'प्रिंट हो रहा है...' : 'Printing...') : (language === 'hi' ? 'प्रिंट करें / Save PDF' : 'Print / Save PDF (Single A4)')}</span>
            </button>

            {/* Open Dedicated Standalone Single A4 PDF View */}
            {onOpenDedicatedPdfView && (
              <button
                id="btn-modal-open-pdf-view"
                type="button"
                onClick={onOpenDedicatedPdfView}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-amber-300 font-semibold text-xs border border-amber-500/30 transition-all active:scale-95 cursor-pointer"
                title="Switch to dedicated full Single A4 PDF report mode"
              >
                <span>📄 {language === 'hi' ? 'समर्पित A4 PDF दृश्य' : 'Single A4 PDF Mode'}</span>
              </button>
            )}

            {/* Direct Open in New Tab Link */}
            {blobUrl && (
              <a
                id="btn-modal-open-new-window"
                href={blobUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-amber-300 font-semibold text-xs border border-amber-500/30 transition-all active:scale-95 cursor-pointer decoration-transparent"
                title="Opens clean printable window outside iframe restrictions"
              >
                <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
                <span>{language === 'hi' ? 'नई विंडो में खोलें' : 'Open in New Tab'}</span>
              </a>
            )}

            {/* Download Standalone HTML */}
            <button
              id="btn-modal-download-html"
              type="button"
              onClick={handleDownloadHtml}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-medium text-xs border border-zinc-700 transition-all active:scale-95 cursor-pointer"
              title="Download standalone offline slip document"
            >
              <Download className="w-3.5 h-3.5 text-zinc-400" />
              <span>{language === 'hi' ? 'पर्ची डाउनलोड (HTML)' : 'Download Slip (.html)'}</span>
            </button>

            {/* Copy text */}
            <button
              id="btn-modal-copy-text"
              type="button"
              onClick={handleCopyText}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-medium text-xs border border-zinc-700 transition-all cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">{language === 'hi' ? 'कॉपी हो गया' : 'Copied'}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-zinc-400" />
                  <span>{language === 'hi' ? 'टेक्स्ट कॉपी करें' : 'Copy Text'}</span>
                </>
              )}
            </button>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-zinc-400">
            <span className="inline-flex items-center gap-1 text-amber-400 font-bold font-mono">
              <QrCode className="w-3.5 h-3.5 text-amber-400" />
              QR Enabled
            </span>
            <span>&bull;</span>
            <span className="text-zinc-300 font-medium">1 Single A4 Sheet</span>
          </div>
        </div>

        {/* Helpful notice or status alert */}
        {printStatusNotice ? (
          <div className="px-5 py-2 bg-amber-500/20 border-b border-amber-500/30 text-[11px] text-amber-200 flex items-center justify-between gap-2 shrink-0 print:hidden">
            <div className="flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 shrink-0 text-amber-400" />
              <span>{printStatusNotice}</span>
            </div>
            {blobUrl && (
              <a
                href={blobUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-amber-300 font-bold underline text-[11px]"
              >
                {language === 'hi' ? 'नई विंडो खोलें' : 'Open in New Tab'}
              </a>
            )}
          </div>
        ) : (
          <div className="px-5 py-1.5 bg-zinc-900/60 border-b border-zinc-800/80 text-[10.5px] text-zinc-400 flex items-center justify-between gap-2 shrink-0 print:hidden">
            <div className="flex items-center gap-1.5">
              <Info className="w-3 h-3 shrink-0 text-amber-400" />
              <span>
                {language === 'hi'
                  ? 'स्मार्टफोन से QR कोड स्कैन करने पर यह रिपोर्ट लाइव खुल जाएगी। प्रिंटर A4 पर 1 पेज में सेट है।'
                  : 'Scanning the QR code with any smartphone camera opens this exact live report. Output is strictly calibrated for single A4 page.'}
              </span>
            </div>
            <span className="font-mono text-zinc-500 text-[10px]">soofiyan.com</span>
          </div>
        )}

        {/* Paper Container Preview (White Paper Sheet) */}
        <div className="flex-1 overflow-y-auto p-2 sm:p-4 bg-zinc-950/80 flex justify-center print:p-0 print:bg-white print:overflow-visible">
          <div className="w-full max-w-[210mm] bg-white text-zinc-900 rounded shadow-2xl p-2 sm:p-4 border border-zinc-400 text-xs print:p-0 print:shadow-none print:border-none">
            <PrintableCalculationSlip
              results={results}
              input={input}
              propertyType={propertyType}
              language={language}
              forceVisible={true}
              qrDataUrl={qrDataUrl}
            />
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-2.5 bg-[#161822] border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-400 shrink-0 print:hidden">
          <div className="flex items-center gap-2">
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[11px] font-medium text-zinc-300">
              Chamber of Advocate A. Soofiyan &bull; <strong className="text-amber-400">soofiyan.com</strong>
            </span>
          </div>
          <button
            id="btn-modal-footer-close"
            type="button"
            onClick={onClose}
            className="px-3 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs transition-colors cursor-pointer"
          >
            {language === 'hi' ? 'बंद करें' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
