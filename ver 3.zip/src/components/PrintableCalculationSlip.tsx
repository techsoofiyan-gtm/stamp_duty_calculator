import React from 'react';
import { CalculationInput, CalculationResult, Language, PropertyType } from '../types';
import {
  formatINR,
  formatNumber,
  formatLakhCrore,
  formatIndianCurrencyWords,
  convertToSqFeet,
  convertToBiswa,
  convertToPuccaBigha,
  convertToAcres,
  TRANSLATIONS,
} from '../constants/stampDutyConfig';
import { Scale, Globe } from 'lucide-react';

interface PrintableCalculationSlipProps {
  results: CalculationResult;
  input: CalculationInput;
  propertyType: PropertyType;
  language: Language;
  forceVisible?: boolean;
  qrDataUrl?: string;
}

export const PrintableCalculationSlip: React.FC<PrintableCalculationSlipProps> = ({
  results,
  input,
  propertyType,
  language,
  forceVisible = false,
  qrDataUrl,
}) => {
  const t = TRANSLATIONS[language];
  const isPlot = propertyType === 'plot';

  // Current print date and time in Indian locale format
  const now = new Date();
  const printDateStr = now.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
  const printTimeStr = now.toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  const refCode = `SOOF-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}-${String(Math.floor(1000 + Math.random() * 9000))}`;

  const unitLabel = t.unitLabels[input.areaUnit] || input.areaUnit;
  const buyerCategoryLabel = t.buyerOptions[input.buyerCategory] || input.buyerCategory;

  const sqFeet = convertToSqFeet(results.convertedAreaSqM);
  const biswa = convertToBiswa(results.convertedAreaSqM);
  const puccaBigha = convertToPuccaBigha(results.convertedAreaSqM);
  const acres = convertToAcres(results.convertedAreaSqM);

  const dimensionText =
    input.dimensionCalcEnabled && input.dimensionLength && input.dimensionHeight
      ? `${input.dimensionLength} × ${input.dimensionHeight} ${input.dimensionUnit === 'feet' ? 'ft' : 'm'} = ${formatNumber(input.dimensionUnit === 'feet' ? sqFeet : results.convertedAreaSqM, 0)} ${input.dimensionUnit === 'feet' ? 'sq. ft' : 'sq. m'}`
      : `${input.areaValue} ${unitLabel}`;

  return (
    <div
      id="printable-calculation-slip"
      className={`${
        forceVisible ? 'block' : 'hidden print:block'
      } w-full max-w-[210mm] mx-auto bg-white text-zinc-900 font-sans text-[9.5px] leading-tight p-4 sm:p-5 print:p-0 print:border-none print:w-full print:max-w-none print:h-[284mm] print:min-h-[284mm] print:max-h-[284mm] print:overflow-hidden print:flex print:flex-col print:justify-between`}
    >
      {/* 1. Letterhead / Advocate Header with soofiyan.com branding & QR Code */}
      <div>
        <div className="border-b-2 border-zinc-950 pb-2 mb-2">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-2.5">
              <div className="w-10 h-10 border border-zinc-800 rounded flex items-center justify-center text-zinc-950 shrink-0 mt-0.5 bg-zinc-100">
                <Scale className="w-5 h-5 text-amber-700" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-sm sm:text-base font-serif font-black tracking-tight text-zinc-950 uppercase">
                    {t.printOfficeTitle}
                  </h1>
                  <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 text-[9px] font-black tracking-wide">
                    <Globe className="w-2.5 h-2.5 text-amber-700" />
                    soofiyan.com
                  </span>
                </div>
                <p className="text-[10px] font-bold text-zinc-800 leading-tight mt-0.5">
                  {t.printOfficeSub}
                </p>
                <p className="text-[8.5px] text-zinc-600">
                  Kanpur Bar Association • Civil & Revenue Court • Sub-Registrar Complex, Kanpur Nagar & Dehat
                </p>
              </div>
            </div>

            {/* Right Header: QR Code with "Scan to View Digital PDF Report" */}
            <div className="flex items-center gap-2 shrink-0 bg-zinc-50 border border-zinc-300 rounded p-1.5">
              {qrDataUrl ? (
                <img
                  src={qrDataUrl}
                  alt="Scan to View PDF Report on soofiyan.com"
                  className="w-12 h-12 border border-zinc-300 rounded bg-white p-0.5 shrink-0 object-contain"
                />
              ) : (
                <div className="w-12 h-12 border border-dashed border-zinc-400 rounded flex items-center justify-center text-[7px] text-zinc-500 text-center">
                  QR Code
                </div>
              )}
              <div className="text-left text-[8px] leading-tight">
                <div className="font-bold text-zinc-900 uppercase">Scan to View</div>
                <div className="font-extrabold text-amber-700">soofiyan.com</div>
                <div className="text-zinc-600 font-semibold">Digital PDF Report</div>
                <div className="font-mono text-[7px] text-zinc-500 font-bold mt-0.5">{refCode}</div>
              </div>
            </div>
          </div>

          {/* Standard subtitle bar */}
          <div className="mt-1.5 pt-1 border-t border-zinc-200 flex items-center justify-between text-[8.5px] text-zinc-700">
            <span className="font-extrabold text-zinc-900">
              {t.printSlipTitle}
            </span>
            <div className="flex items-center gap-3 font-medium">
              <span><strong>Ref:</strong> {refCode}</span>
              <span><strong>Date:</strong> {printDateStr}, {printTimeStr}</span>
              <span className="italic hidden sm:inline">{t.printRevenueStandard}</span>
            </div>
          </div>
        </div>

        {/* 2. Property & Valuation Parameters Grid */}
        <div className="mb-2">
          <h2 className="text-[9px] font-extrabold uppercase tracking-wider text-zinc-950 bg-zinc-100 px-2 py-0.5 border-l-3 border-zinc-900 mb-1">
            {t.printPropertyDetailsTitle}
          </h2>

          <div className="grid grid-cols-4 gap-2 border border-zinc-300 rounded p-1.5 bg-zinc-50/80 text-[9px]">
            <div>
              <div className="text-zinc-500 text-[8px] uppercase font-bold">{t.localitySummary}</div>
              <div className="font-extrabold text-zinc-950 truncate" title={input.localityName || 'Kanpur Nagar'}>
                {input.localityName || 'Kanpur Urban/Rural'}
              </div>
            </div>

            <div>
              <div className="text-zinc-500 text-[8px] uppercase font-bold">{t.propertyType}</div>
              <div className="font-extrabold text-zinc-950">
                {isPlot ? t.plotOption : t.agriculturalOption}
              </div>
            </div>

            <div>
              <div className="text-zinc-500 text-[8px] uppercase font-bold">{t.landAreaEntered}</div>
              <div className="font-extrabold text-zinc-950 font-mono">
                {dimensionText}
              </div>
            </div>

            <div>
              <div className="text-zinc-500 text-[8px] uppercase font-bold">{t.buyerCategory}</div>
              <div className="font-extrabold text-zinc-950">
                {buyerCategoryLabel}
              </div>
            </div>
          </div>

          {/* Awadh / Doab Revenue Standard Conversions */}
          <div className="mt-1 flex items-center justify-between bg-zinc-50 border border-zinc-200 rounded px-2 py-1 text-[8.5px] text-zinc-700 font-mono">
            <span><strong>Sq. Metres:</strong> {formatNumber(results.convertedAreaSqM, 2)} m²</span>
            <span><strong>Sq. Feet:</strong> {formatNumber(sqFeet, 0)} ft²</span>
            <span><strong>Biswa:</strong> {formatNumber(biswa, 2)}</span>
            <span><strong>Pucca Bigha:</strong> {formatNumber(puccaBigha, 3)}</span>
            <span><strong>Hectares:</strong> {formatNumber(results.convertedAreaHectares, 4)} ha</span>
            <span><strong>Acres:</strong> {formatNumber(acres, 3)} ac</span>
          </div>
        </div>

        {/* 3. Valuation Benchmark (Sec 47-A Indian Stamp Act) */}
        <div className="mb-2">
          <div className="grid grid-cols-3 gap-2 bg-sky-50/70 border border-sky-200 rounded p-2 text-[9px]">
            <div>
              <div className="text-[7.5px] uppercase font-bold text-zinc-600">Circle Rate Assessment</div>
              <div className="font-mono font-bold text-zinc-950 text-[11px]">{formatINR(results.circleRateValue)}</div>
              <div className="text-[7.5px] text-zinc-500">@ ₹{formatNumber(input.circleRate || 0, 0)} / {isPlot ? 'sq. m' : 'hectare'}</div>
            </div>

            <div>
              <div className="text-[7.5px] uppercase font-bold text-zinc-600">Declared Consideration</div>
              <div className="font-mono font-bold text-zinc-950 text-[11px]">
                {input.declaredPrice ? formatINR(Number(input.declaredPrice)) : 'Not Declared (₹0)'}
              </div>
              <div className="text-[7.5px] text-zinc-500">Agreed sale deed price</div>
            </div>

            <div className="border-l-3 border-sky-600 pl-2 bg-sky-100/60 rounded-r">
              <div className="text-[7.5px] uppercase font-black text-sky-900">Sec 47-A Taxable Base</div>
              <div className="font-mono font-black text-sky-950 text-[11.5px]">{formatINR(results.propertyValue)}</div>
              <div className="text-[7.5px] text-sky-800 font-bold">Higher of Circle Rate vs Declared</div>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Statutory Dues Schedule Table */}
      <div className="my-1">
        <h2 className="text-[9px] font-extrabold uppercase tracking-wider text-zinc-950 bg-zinc-100 px-2 py-0.5 border-l-3 border-zinc-900 mb-1">
          {t.statutoryFeesTitle}
        </h2>

        <table className="w-full border-collapse border border-zinc-400 text-left text-[9.5px]">
          <thead>
            <tr className="bg-zinc-100 text-zinc-900 border-b border-zinc-400 font-black uppercase text-[8.5px]">
              <th className="p-1 border-r border-zinc-300 w-6 text-center">#</th>
              <th className="p-1 border-r border-zinc-300">{t.printParticulars}</th>
              <th className="p-1 border-r border-zinc-300 text-right w-36">Taxable Base</th>
              <th className="p-1 text-right font-black w-36">{t.printCalculatedDues}</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-zinc-200">
              <td className="p-1 border-r border-zinc-200 text-center font-mono font-semibold">1</td>
              <td className="p-1 border-r border-zinc-200">
                <div className="font-bold text-zinc-950">{t.stampDuty}</div>
                <div className="text-[8px] text-zinc-500">{t.stampDutyRateText}</div>
              </td>
              <td className="p-1 border-r border-zinc-200 text-right font-mono text-zinc-800 font-semibold">
                {formatINR(results.propertyValue)}
              </td>
              <td className="p-1 text-right font-mono font-extrabold text-zinc-950">
                {formatINR(results.stampDutyAmount)}
              </td>
            </tr>

            <tr className="border-b border-zinc-200">
              <td className="p-1 border-r border-zinc-200 text-center font-mono font-semibold">2</td>
              <td className="p-1 border-r border-zinc-200">
                <div className="font-bold text-zinc-950">{t.registrationFee}</div>
                <div className="text-[8px] text-zinc-500">{t.registrationFeeText}</div>
              </td>
              <td className="p-1 border-r border-zinc-200 text-right font-mono text-zinc-800 font-semibold">
                {formatINR(results.propertyValue)}
              </td>
              <td className="p-1 text-right font-mono font-extrabold text-zinc-950">
                {formatINR(results.registrationFeeAmount)}
              </td>
            </tr>

            {/* Government Dues Subtotal */}
            <tr className="bg-zinc-50 font-bold border-b border-zinc-300 text-[9px]">
              <td colSpan={3} className="p-1 border-r border-zinc-300 text-right text-zinc-700">
                {t.govtDuesSubtotal}:
              </td>
              <td className="p-1 text-right font-mono font-black text-zinc-950">
                {formatINR(results.governmentDues || (results.stampDutyAmount + results.registrationFeeAmount))}
              </td>
            </tr>

            {/* Purchaser Expenses (2-Column Section) */}
            {results.totalExpenses > 0 && (
              <tr className="bg-amber-50/70 border-b border-zinc-300 text-[8.5px]">
                <td className="p-1 border-r border-zinc-200 text-center font-mono font-semibold align-top pt-1.5">3-8</td>
                <td colSpan={2} className="p-1 border-r border-zinc-200 text-zinc-950">
                  <div className="font-black uppercase text-[8px] text-amber-900 mb-0.5">
                    {t.expensesSectionTitle} (Incidental, Typing, Audit &amp; Legal Documentation)
                  </div>
                  <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 text-[8px] text-amber-950">
                    <div>• {t.expTypingOnline}: <strong>{formatINR(results.itemizedExpenses?.typingOnline ?? 1200)}</strong></div>
                    <div>• {t.expAudit}: <strong>{formatINR(results.itemizedExpenses?.audit ?? 1000)}</strong></div>
                    <div>• {t.expAdvocateFee}: <strong>{formatINR(results.itemizedExpenses?.advocateFee ?? 1500)}</strong></div>
                    <div>• {t.expGpsPhoto}: <strong>{formatINR(results.itemizedExpenses?.gpsPhoto ?? 100)}</strong></div>
                    <div>• {t.expCertification}: <strong>{formatINR(results.itemizedExpenses?.certification ?? 1500)}</strong></div>
                    <div>• {t.expNaqshaNazari}: <strong>{formatINR(results.itemizedExpenses?.naqshaNazari ?? 1000)}</strong></div>
                  </div>
                </td>
                <td className="p-1 text-right font-mono font-black text-amber-950 align-bottom">
                  {formatINR(results.totalExpenses)}
                </td>
              </tr>
            )}

            {/* Grand Total Row */}
            <tr className="bg-zinc-100 font-extrabold border-t-2 border-zinc-950 text-[11px]">
              <td colSpan={2} className="p-1.5 border-r border-zinc-300">
                <div className="uppercase tracking-wide text-zinc-950 font-black">
                  {results.totalExpenses > 0 ? t.grandTotalPayable : t.totalPayable}
                </div>
                <div className="text-[7.5px] font-normal text-zinc-600">
                  {results.totalExpenses > 0 ? t.grandTotalSubtext : t.totalPayableSubtext}
                </div>
              </td>
              <td className="p-1.5 border-r border-zinc-300 text-right font-mono text-zinc-500">
                —
              </td>
              <td className="p-1.5 text-right font-mono text-sm font-black text-zinc-950">
                {formatINR(results.grandTotal || results.totalPayable)}
              </td>
            </tr>
          </tbody>
        </table>

        {/* Total In Words Banner */}
        <div className="mt-1.5 p-1.5 rounded border border-zinc-300 bg-amber-50/60 flex items-center justify-between gap-1 text-[9px]">
          <div>
            <span className="font-bold text-zinc-800">{t.printTotalPayableWords}: </span>
            <span className="font-serif italic font-bold text-zinc-950">
              {formatIndianCurrencyWords(results.grandTotal || results.totalPayable, language)}
            </span>
          </div>
          <div className="text-amber-900 text-[8.5px] font-black font-mono">
            {formatLakhCrore(results.grandTotal || results.totalPayable, language)}
          </div>
        </div>

        {results.femaleConcessionApplied && (
          <div className="mt-1 p-1 bg-emerald-50 border border-emerald-300 rounded text-[8px] text-emerald-900 font-bold">
            &check; {results.stampDutyRate === 0.06 ? t.femaleBenefitBadge : t.jointFemaleBenefitBadge}
          </div>
        )}
      </div>

      {/* 5. Statutory Notes, 6. Endorsements & 7. Watermark */}
      <div>
        <div className="mb-2 p-1.5 rounded border border-zinc-300 bg-zinc-50 text-[8px] text-zinc-700 leading-normal">
          <div className="font-black text-zinc-950 uppercase tracking-wide">
            {t.printLegalNoticeTitle} (Section 47-A, Indian Stamp Act 1899 &amp; UP Stamp Rules)
          </div>
          <p className="mt-0.5">
            {t.disclaimerText} All statutory stamp dues rounded up to nearest top whole rupee (Math.ceil). Verification available at igrsup.gov.in.
          </p>
        </div>

        {/* 6. Signature & Chamber Seal Row with Left Thumb Impression */}
        <div className="pt-2 border-t-1.5 border-zinc-700 grid grid-cols-3 gap-3 text-[8.5px]">
          <div className="text-center flex flex-col justify-end">
            <div className="h-8 border-b border-dashed border-zinc-400 mb-0.5" />
            <div className="font-bold text-zinc-950">{t.printSignAdvocate}</div>
            <div className="text-zinc-600 text-[7.5px]">Advocate A. Soofiyan • soofiyan.com</div>
            <div className="text-zinc-500 text-[7px]">Counsel for Purchaser &amp; Scrutiny</div>
          </div>

          <div className="text-center flex flex-col justify-end">
            <div className="h-9 border border-dashed border-zinc-400 rounded bg-zinc-50/50 mb-1 flex items-center justify-center text-[7.5px] text-zinc-500 font-medium">
              Left Thumb Impression (LTI) &amp; Sign
            </div>
            <div className="font-bold text-zinc-950">{t.printSignClient}</div>
            <div className="text-zinc-600 text-[7.5px]">Purchaser / Executant Endorsement</div>
          </div>

          <div className="text-center flex flex-col justify-end">
            <div className="h-8 border-b border-dashed border-zinc-400 mb-0.5" />
            <div className="font-bold text-zinc-950">Sub-Registrar Office Endorsement</div>
            <div className="text-zinc-600 text-[7.5px]">Sub-Registrar Complex, Kanpur</div>
            <div className="text-zinc-500 text-[7px]">Official Registry &amp; Entry Stamp</div>
          </div>
        </div>

        {/* 7. Footer Watermark */}
        <div className="mt-2 pt-1 border-t border-zinc-200 flex items-center justify-between text-[7.5px] text-zinc-600">
          <span>🌐 Digitally authenticated via <strong>soofiyan.com</strong></span>
          <span>Advocate A. Soofiyan • Kanpur Bar Association</span>
          <span>Strict Single-Sheet Assessment &bull; <strong>Page 1 of 1</strong></span>
        </div>
      </div>
    </div>
  );
};
