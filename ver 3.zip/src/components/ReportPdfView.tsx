import React, { useEffect, useState } from 'react';
import { CalculationInput, CalculationResult, Language, PropertyType } from '../types';
import { PrintableCalculationSlip } from './PrintableCalculationSlip';
import { buildReportShareUrl, generateQrDataUrl } from '../utils/qrHelper';
import { Printer, ArrowLeft, Download } from 'lucide-react';
import { generatePrintableSlipHtml } from '../utils/printHtmlGenerator';

interface ReportPdfViewProps {
  results: CalculationResult;
  input: CalculationInput;
  propertyType: PropertyType;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenCalculator: () => void;
}

export const ReportPdfView: React.FC<ReportPdfViewProps> = ({
  results,
  input,
  propertyType,
  language,
  onLanguageChange,
  onOpenCalculator,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  // Generate QR code pointing to this exact report
  useEffect(() => {
    let isMounted = true;
    const shareUrl = buildReportShareUrl(input, propertyType);
    generateQrDataUrl(shareUrl).then((url) => {
      if (isMounted) {
        setQrDataUrl(url);
      }
    });
    return () => {
      isMounted = false;
    };
  }, [input, propertyType]);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadHtml = () => {
    const htmlContent = generatePrintableSlipHtml(
      results,
      input,
      propertyType,
      language,
      qrDataUrl
    );
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Advocate_Soofiyan_Report_${propertyType}_Kanpur.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-amber-500 selection:text-zinc-950">
      {/* Sleek Top Reader Bar (Screen only, completely omitted when printing) */}
      <header className="print:hidden sticky top-0 z-50 bg-zinc-900/95 backdrop-blur-md border-b border-zinc-800 px-4 py-2.5 shadow-lg">
        <div className="max-w-5xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenCalculator}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white text-xs font-semibold transition border border-zinc-700"
              title="Open the interactive calculator"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Full Calculator</span>
            </button>

            <div className="hidden sm:block border-l border-zinc-700 pl-3">
              <div className="text-xs font-bold text-zinc-200">
                Advocate A. Soofiyan — Kanpur Legal Practice
              </div>
              <div className="text-[11px] text-zinc-400">
                Official Single-Sheet A4 Calculation Slip &bull; soofiyan.com
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Language Toggle */}
            <div className="inline-flex bg-zinc-800 p-0.5 rounded-lg border border-zinc-700 text-xs">
              <button
                type="button"
                onClick={() => onLanguageChange('en')}
                className={`px-2.5 py-1 rounded-md transition font-semibold ${
                  language === 'en'
                    ? 'bg-amber-500 text-zinc-950 shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => onLanguageChange('hi')}
                className={`px-2.5 py-1 rounded-md transition font-semibold ${
                  language === 'hi'
                    ? 'bg-amber-500 text-zinc-950 shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                हिंदी
              </button>
            </div>

            {/* Offline HTML Backup Download */}
            <button
              onClick={handleDownloadHtml}
              className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold transition border border-zinc-700"
              title="Download standalone HTML report"
            >
              <Download className="w-3.5 h-3.5 text-zinc-400" />
              <span>Save HTML</span>
            </button>

            {/* Primary Print / Save PDF Button */}
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-md transition transform active:scale-95"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save PDF</span>
            </button>
          </div>
        </div>
      </header>

      {/* Screen Presentation Wrapper */}
      <main className="flex-1 py-4 sm:py-8 px-2 sm:px-4 flex justify-center items-start overflow-x-auto print:p-0 print:m-0 print:overflow-visible">
        <div className="w-full max-w-[210mm] bg-white rounded-md shadow-2xl border border-zinc-300 print:shadow-none print:border-none print:rounded-none">
          <PrintableCalculationSlip
            results={results}
            input={input}
            propertyType={propertyType}
            language={language}
            forceVisible={true}
            qrDataUrl={qrDataUrl}
          />
        </div>
      </main>
    </div>
  );
};
