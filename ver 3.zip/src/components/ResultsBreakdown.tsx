import React, { useState } from 'react';
import { CalculationInput, CalculationResult, Language, PropertyType } from '../types';
import {
  formatINR,
  formatNumber,
  formatLakhCrore,
  TRANSLATIONS,
} from '../constants/stampDutyConfig';
import {
  Coins,
  FileText,
  BadgePercent,
  Check,
  Copy,
  ExternalLink,
  ShieldAlert,
  ArrowUpRight,
  TrendingUp,
  Printer,
  MapPin,
  Receipt,
} from 'lucide-react';
import { PrintableCalculationSlip } from './PrintableCalculationSlip';
import { PrintModal } from './PrintModal';

interface ResultsBreakdownProps {
  results: CalculationResult;
  input: CalculationInput;
  propertyType: PropertyType;
  language: Language;
  hasValidInputs: boolean;
  onTriggerPrint?: () => void;
}

export const ResultsBreakdown: React.FC<ResultsBreakdownProps> = ({
  results,
  input,
  propertyType,
  language,
  hasValidInputs,
  onTriggerPrint,
}) => {
  const t = TRANSLATIONS[language];
  const [copied, setCopied] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  const handlePrint = () => {
    if (onTriggerPrint) {
      onTriggerPrint();
    } else {
      setIsPrintModalOpen(true);
    }
  };

  if (!hasValidInputs) {
    return (
      <div
        id="results-empty-state"
        className="p-6 sm:p-8 rounded-2xl bg-[#11131a] border border-amber-500/20 text-center flex flex-col items-center justify-center min-h-[300px]"
      >
        <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-3">
          <Coins className="w-7 h-7" />
        </div>
        <h3 className="text-lg font-bold text-zinc-200">
          {language === 'hi' ? 'अनुमान विवरण देखने के लिए विवरण भरें' : 'Enter Details to Generate Estimate'}
        </h3>
        <p className="text-sm text-zinc-400 max-w-md mt-1.5 leading-relaxed">
          {language === 'hi'
            ? 'कृपया संपत्ति का क्षेत्रफल एवं सरकारी सर्किल रेट दर्ज करें। स्टाम्प शुल्क एवं रजिस्ट्री शुल्क का सटीक विवरण स्वतः आ जाएगा।'
            : 'Enter the land area and the applicable DM Circle Rate to calculate the exact Kanpur stamp duty and registration fee.'}
        </p>
      </div>
    );
  }

  const isPlot = propertyType === 'plot';
  const isDeclaredHigher = results.valuationBasis === 'declared_price';
  const stampPercent = (results.stampDutyRate * 100).toFixed(1).replace('.0', '');
  const regFeePercent = (results.registrationFeeRate * 100).toFixed(1).replace('.0', '');

  const handleCopySummary = async () => {
    const expensesText = results.totalExpenses > 0
      ? `
Purchaser's Incidental & Registration Expenses:
- Type, online etc: ${formatINR(results.itemizedExpenses?.typingOnline ?? 1200)}
- Audit: ${formatINR(results.itemizedExpenses?.audit ?? 1000)}
- Advocate's fee: ${formatINR(results.itemizedExpenses?.advocateFee ?? 1500)}
- GPS photo: ${formatINR(results.itemizedExpenses?.gpsPhoto ?? 100)}
- Certification: ${formatINR(results.itemizedExpenses?.certification ?? 1500)}
- Naqsha Nazari: ${formatINR(results.itemizedExpenses?.naqshaNazari ?? 1000)}
Purchaser Expenses Subtotal: ${formatINR(results.totalExpenses)}
` : '';

    const summaryText = `--- Kanpur Property Stamp Duty & Registration Estimate ---
${input.localityName ? `Village / Locality: ${input.localityName}\n` : ''}Property Type: ${isPlot ? 'Residential/Commercial Plot' : 'Agricultural Land'}
Area: ${formatNumber(results.convertedAreaSqM, 2)} sq. m (${formatNumber(results.convertedAreaHectares, 4)} hectare)
Circle Rate Assessed Value: ${formatINR(results.circleRateValue)}
Declared Sale Agreement Price: ${results.declaredPrice > 0 ? formatINR(results.declaredPrice) : 'Not Specified'}
Valuation Used (Max Rule): ${formatINR(results.propertyValue)} (${isDeclaredHigher ? 'Declared Price' : 'Circle Rate Value'})

1. Government Dues:
- Stamp Duty (${stampPercent}%): ${formatINR(results.stampDutyAmount)}
- Registration Fee (${regFeePercent}%): ${formatINR(results.registrationFeeAmount)}
Government Dues Subtotal: ${formatINR(results.governmentDues || (results.stampDutyAmount + results.registrationFeeAmount))}
${expensesText}
---------------------------------------------
GRAND TOTAL (Expenses from Purchaser): ${formatINR(results.grandTotal || results.totalPayable)} ${formatLakhCrore(results.grandTotal || results.totalPayable, language)}
---------------------------------------------
Estimated via Kanpur Stamp Duty Calculator (Advocate A. Soofiyan)
Please verify on igrsup.gov.in before registration.`;

    try {
      await navigator.clipboard.writeText(summaryText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // fallback
    }
  };

  return (
    <>
      <div
        id="results-breakdown-card"
        className="rounded-2xl bg-gradient-to-b from-[#161823] via-[#12131b] to-[#0c0d12] border-2 border-amber-400/40 p-5 sm:p-7 shadow-[0_10px_35px_rgba(0,0,0,0.6)] relative overflow-hidden print:hidden"
      >
        {/* Decorative Gold Glow accent */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header with Title and Dedicated Action Buttons */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-amber-500/20">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-amber-400/10 text-amber-300 border border-amber-400/30">
                <FileText className="w-4 h-4" />
              </span>
              <h2 className="text-lg sm:text-xl font-bold text-zinc-100 font-serif">
                {t.breakdownTitle}
              </h2>
            </div>
            <p className="text-xs text-zinc-400 mt-1">
              {t.breakdownSubtitle}
            </p>
          </div>

          {/* Action Buttons: Dedicated Print Button & Copy Summary Button */}
          <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
            {/* Dedicated Print Button */}
            <button
              id="btn-print-breakdown"
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 hover:text-amber-200 text-xs font-semibold border border-amber-400/40 hover:border-amber-400 transition-all shadow-sm active:scale-95 cursor-pointer"
              title={language === 'hi' ? 'प्रिंट करें अथवा PDF सहेजें' : 'Print Calculation Slip (Printer-Friendly)'}
            >
              <Printer className="w-3.5 h-3.5 text-amber-400" />
              <span>{t.printEstimate}</span>
            </button>

            {/* Copy button */}
            <button
              id="btn-copy-summary"
              type="button"
              onClick={handleCopySummary}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800/80 hover:bg-zinc-700/90 text-amber-300 text-xs font-medium border border-amber-400/30 transition-all cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">{t.summaryCopied}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-amber-400" />
                  <span>{t.copySummary}</span>
                </>
              )}
            </button>
          </div>
        </div>

      {/* Converted Area & Locality summary */}
      <div className="mt-5 p-3.5 rounded-xl bg-[#0f1016] border border-zinc-800 space-y-2 text-xs">
        {input.localityName && (
          <div className="flex items-center gap-2 pb-2 border-b border-zinc-800/80">
            <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="text-zinc-400 font-medium">
              {t.localitySummary}:
            </span>
            <span className="font-semibold text-zinc-100">
              {input.localityName}
            </span>
          </div>
        )}

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <span className="text-zinc-400 font-medium">
            {t.convertedAreaLabel}:
          </span>
          <div className="flex items-center gap-2 font-mono text-zinc-200">
            <span className="text-amber-300 font-semibold">
              {formatNumber(results.convertedAreaSqM, 2)} sq. m
            </span>
            <span className="text-zinc-500">|</span>
            <span className="text-amber-200">
              {formatNumber(results.convertedAreaHectares, 4)} hectare
            </span>
            {isPlot ? (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 font-sans">
                (Plot Rate Unit)
              </span>
            ) : (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 font-sans">
                (Agri Rate Unit)
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Valuation Basis Box (Circle Rate vs Declared Price rule) */}
      <div className="mt-4 p-4 rounded-xl bg-[#11131a] border border-amber-500/20">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div>
            <div className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">
              {t.propertyValueUsed}
            </div>
            <div className="text-xl sm:text-2xl font-bold text-amber-400 font-mono mt-0.5 flex items-baseline gap-2 flex-wrap">
              <span>{formatINR(results.propertyValue)}</span>
              <span className="text-xs sm:text-sm font-sans font-normal text-amber-200/80">
                {formatLakhCrore(results.propertyValue, language)}
              </span>
            </div>
          </div>

          <span
            className={`text-[11px] px-2.5 py-1 rounded-full font-medium border shrink-0 ${
              isDeclaredHigher
                ? 'bg-amber-400/10 text-amber-300 border-amber-400/30'
                : 'bg-emerald-400/10 text-emerald-300 border-emerald-400/30'
            }`}
          >
            {isDeclaredHigher ? 'Declared Price Applied' : 'Circle Rate Applied'}
          </span>
        </div>

        {/* Comparison Details */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-2 border-t border-zinc-800/80">
          <div className="flex items-center justify-between text-zinc-400">
            <span>{t.circleRateAssessedValue}:</span>
            <span className="font-mono text-zinc-300 font-medium">
              {formatINR(results.circleRateValue)}
            </span>
          </div>
          <div className="flex items-center justify-between text-zinc-400">
            <span>{t.declaredPriceProvided}:</span>
            <span className="font-mono text-zinc-300 font-medium">
              {results.declaredPrice > 0 ? formatINR(results.declaredPrice) : '—'}
            </span>
          </div>
        </div>

        {/* Reason note */}
        <div className="mt-2 text-[11px] text-zinc-400 flex items-center gap-1.5">
          <TrendingUp className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span>
            {results.declaredPrice > results.circleRateValue
              ? t.valuationBasisDeclared
              : results.declaredPrice > 0 && results.declaredPrice === results.circleRateValue
              ? t.valuationBasisEqual
              : t.valuationBasisCircle}
          </span>
        </div>
      </div>

      {/* Duty & Fee Breakdowns */}
      <div className="mt-4 space-y-3">
        {/* Stamp Duty */}
        <div
          id="breakdown-stamp-duty"
          className="p-4 rounded-xl bg-[#0f1017] border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
        >
          <div>
            <div className="flex items-center gap-2">
              <BadgePercent className="w-4 h-4 text-amber-400" />
              <span className="text-sm font-semibold text-zinc-200">
                {t.stampDuty}
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-amber-400/10 text-amber-300 border border-amber-400/30 font-mono font-bold">
                {stampPercent}%
              </span>
            </div>
            <p className="text-[11px] text-zinc-400 mt-0.5">
              {t.stampDutyRateText}
            </p>
          </div>
          <div className="text-right sm:text-right">
            <span className="text-lg sm:text-xl font-bold text-zinc-100 font-mono">
              {formatINR(results.stampDutyAmount)}
            </span>
            <div className="text-[11px] text-zinc-400 font-mono">
              {formatLakhCrore(results.stampDutyAmount, language)}
            </div>
          </div>
        </div>

        {/* Registration Fee */}
        <div
          id="breakdown-registration-fee"
          className="p-4 rounded-xl bg-[#0f1017] border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
        >
          <div>
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-400" />
              <span className="text-sm font-semibold text-zinc-200">
                {t.registrationFee}
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300 border border-zinc-700 font-mono font-bold">
                {regFeePercent}%
              </span>
            </div>
            <p className="text-[11px] text-zinc-400 mt-0.5">
              {t.registrationFeeText}
            </p>
          </div>
          <div className="text-right sm:text-right">
            <span className="text-lg sm:text-xl font-bold text-zinc-100 font-mono">
              {formatINR(results.registrationFeeAmount)}
            </span>
            <div className="text-[11px] text-zinc-400 font-mono">
              {formatLakhCrore(results.registrationFeeAmount, language)}
            </div>
          </div>
        </div>

        {/* Government Dues Subtotal Banner */}
        <div className="p-3 rounded-lg bg-zinc-900/90 border border-zinc-700/80 flex items-center justify-between text-xs">
          <span className="font-semibold text-zinc-300">
            {t.govtDuesSubtotal}:
          </span>
          <span className="font-mono font-bold text-sm text-zinc-100">
            {formatINR(results.governmentDues || (results.stampDutyAmount + results.registrationFeeAmount))}
          </span>
        </div>
      </div>

      {/* Rebate/Concession Notification if applicable */}
      {results.femaleConcessionApplied && (
        <div className="mt-3 p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            {results.stampDutyRate === 0.06
              ? t.femaleBenefitBadge
              : t.jointFemaleBenefitBadge}
          </span>
        </div>
      )}

      {/* Purchaser's Incidental & Registration Expenses Breakdown */}
      {results.totalExpenses > 0 && (
        <div
          id="breakdown-purchaser-expenses"
          className="mt-4 p-4 rounded-xl bg-[#0e1017] border border-amber-500/25"
        >
          <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <Receipt className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-zinc-200">
                {t.expensesSectionTitle}
              </span>
            </div>
            <span className="text-xs font-mono font-bold text-amber-300 px-2 py-0.5 rounded bg-amber-400/10 border border-amber-400/30">
              {formatINR(results.totalExpenses)}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2.5 text-[11px]">
            {/* 1. Typing, Online */}
            <div className="p-2 rounded bg-zinc-900/60 border border-zinc-800/80 flex items-center justify-between">
              <span className="text-zinc-300">{t.expTypingOnline}</span>
              <span className="font-mono font-semibold text-zinc-100">
                {formatINR(results.itemizedExpenses?.typingOnline ?? 1200)}
              </span>
            </div>

            {/* 2. Audit */}
            <div className="p-2 rounded bg-zinc-900/60 border border-zinc-800/80 flex items-center justify-between">
              <span className="text-zinc-300">{t.expAudit}</span>
              <span className="font-mono font-semibold text-zinc-100">
                {formatINR(results.itemizedExpenses?.audit ?? 1000)}
              </span>
            </div>

            {/* 3. Advocate's fee */}
            <div className="p-2 rounded bg-zinc-900/60 border border-zinc-800/80 flex items-center justify-between">
              <span className="text-zinc-300">{t.expAdvocateFee}</span>
              <span className="font-mono font-semibold text-zinc-100">
                {formatINR(results.itemizedExpenses?.advocateFee ?? 1500)}
              </span>
            </div>

            {/* 4. GPS photo */}
            <div className="p-2 rounded bg-zinc-900/60 border border-zinc-800/80 flex items-center justify-between">
              <span className="text-zinc-300">{t.expGpsPhoto}</span>
              <span className="font-mono font-semibold text-zinc-100">
                {formatINR(results.itemizedExpenses?.gpsPhoto ?? 100)}
              </span>
            </div>

            {/* 5. Certification */}
            <div className="p-2 rounded bg-zinc-900/60 border border-zinc-800/80 flex items-center justify-between">
              <span className="text-zinc-300">{t.expCertification}</span>
              <span className="font-mono font-semibold text-zinc-100">
                {formatINR(results.itemizedExpenses?.certification ?? 1500)}
              </span>
            </div>

            {/* 6. Naqsha Nazari */}
            <div className="p-2 rounded bg-zinc-900/60 border border-zinc-800/80 flex items-center justify-between">
              <span className="text-zinc-300">{t.expNaqshaNazari}</span>
              <span className="font-mono font-semibold text-zinc-100">
                {formatINR(results.itemizedExpenses?.naqshaNazari ?? 1000)}
              </span>
            </div>
          </div>

          <div className="mt-2.5 pt-2 border-t border-zinc-800/80 flex items-center justify-between text-xs font-semibold text-amber-300/90">
            <span>{t.purchaserExpensesSubtotal}:</span>
            <span className="font-mono">{formatINR(results.totalExpenses)}</span>
          </div>
        </div>
      )}

      {/* Grand Total Payable Box (Prominent & Bold) */}
      <div
        id="breakdown-total-payable"
        className="mt-5 p-5 sm:p-6 rounded-xl bg-gradient-to-r from-amber-500/15 via-amber-400/20 to-amber-500/10 border-2 border-amber-400 shadow-[0_0_25px_rgba(212,175,55,0.2)]"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="text-xs uppercase font-bold tracking-widest text-amber-300/90">
              {results.totalExpenses > 0 ? t.grandTotalPayable : t.totalPayable}
            </span>
            <p className="text-[11px] text-zinc-300 mt-0.5">
              {results.totalExpenses > 0
                ? `${t.grandTotalSubtext} [${formatINR(results.governmentDues || (results.stampDutyAmount + results.registrationFeeAmount))} + ${formatINR(results.totalExpenses)}]`
                : t.totalPayableSubtext}
            </p>
          </div>

          <div className="text-left sm:text-right">
            <div className="text-2xl sm:text-3xl md:text-4xl font-black text-amber-300 font-mono tracking-tight drop-shadow-sm">
              {formatINR(results.grandTotal || results.totalPayable)}
            </div>
            <div className="text-xs sm:text-sm font-semibold text-amber-200 mt-0.5">
              {formatLakhCrore(results.grandTotal || results.totalPayable, language)}
            </div>
          </div>
        </div>

        {/* Ceiling rule note */}
        <div className="mt-3 pt-2.5 border-t border-amber-400/20 flex items-center justify-between gap-2 text-[11px] text-amber-300/80 flex-wrap">
          <span className="flex items-center gap-1">
            <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            {t.topRoundingBadge}
          </span>
          <span className="text-zinc-400 text-[10px] font-mono">
            Math.ceil() applied
          </span>
        </div>
        {/* Secondary Full-Width Print Trigger */}
        <button
          id="btn-print-breakdown-secondary"
          type="button"
          onClick={handlePrint}
          className="w-full mt-3 py-2.5 px-4 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 hover:text-amber-200 text-xs font-semibold border border-amber-400/30 hover:border-amber-400/60 flex items-center justify-center gap-2 transition-all shadow-sm active:scale-[0.99] cursor-pointer"
        >
          <Printer className="w-4 h-4 text-amber-400" />
          <span>{t.printEstimateSecondary}</span>
        </button>
      </div>

      {/* Official Portal Action Link */}
      <div className="mt-4 pt-3 flex items-center justify-between text-xs text-zinc-400 border-t border-zinc-800/80 flex-wrap gap-2">
        <a
          id="link-igrsup-portal"
          href="https://igrsup.gov.in"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 text-amber-400 hover:text-amber-300 hover:underline transition-colors"
        >
          <span>{t.verifyOnIgrs}</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
        <span className="text-[11px] text-zinc-500 font-mono">
          Sec 47-A Indian Stamp Act (UP)
        </span>
      </div>
    </div>

    {/* Printer-Friendly Layout (Rendered only on print/PDF) */}
    <PrintableCalculationSlip
      results={results}
      input={input}
      propertyType={propertyType}
      language={language}
    />

    {/* Interactive Print & Export Modal (Fallback if not handled by parent) */}
    {!onTriggerPrint && (
      <PrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        results={results}
        input={input}
        propertyType={propertyType}
        language={language}
      />
    )}
  </>
  );
};
