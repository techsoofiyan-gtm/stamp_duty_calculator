import { AreaUnit, BuyerCategory, PropertyType, PurchaserExpenses } from '../types';

/**
 * ============================================================================
 * KANPUR STAMP DUTY & REGISTRATION FEE CONFIGURATION CONSTANTS
 * Revenue Standard: Awadh / Doab (Kanpur Nagar & Kanpur Dehat, Uttar Pradesh)
 * ============================================================================
 * 
 * NOTE TO ADMINISTRATORS / ADVOCATES:
 * Edit these values if Uttar Pradesh Stamp & Registration Department or
 * District Magistrate circle rate circulars change the baseline rules.
 */

export const DEFAULT_PURCHASER_EXPENSES: PurchaserExpenses = {
  typingOnline: 1200, // type, online etc - 1200 Rs
  audit: 1000, // Audit - 1000Rs
  advocateFee: 1500, // Advocate's fee - 1500Rs
  gpsPhoto: 100, // GPS photo - 100Rs
  certification: 1500, // Certification - 1500Rs
  naqshaNazari: 1000, // Naqsha Nazari - 1000Rs
};

export const KANPUR_REVENUE_FACTORS = {
  // 1 Square Metre = 10.764 Square Feet
  SQ_FT_PER_SQ_METRE: 10.764,

  // 1 Bigha (Pucca) = 22,500 Square Feet = 20 Biswa
  SQ_FT_PER_PUCCA_BIGHA: 22500,

  // 1 Biswa = 1,125 Square Feet (~104.52 Square Metres)
  SQ_FT_PER_BISWA: 1125,

  // Biswa per Pucca Bigha
  BISWA_PER_PUCCA_BIGHA: 20,

  // 1 Hectare = 10,000 Square Metres = 2.471 Acres
  SQ_METRES_PER_HECTARE: 10000,
  ACRES_PER_HECTARE: 2.471,

  // 1 Acre = 4,046.86 Square Metres
  SQ_METRES_PER_ACRE: 4046.86,
} as const;

/**
 * Stamp duty rates under Indian Stamp (Uttar Pradesh Amendment) Act
 * Male: 7%
 * Female (sole): 6% (UP Government provides 1% exemption/rebate for female buyers)
 * Joint (Male+Female): 6.5% (proportional 0.5% effective concession)
 * Joint (Male+Male): 7%
 * Joint (Female+Female): 6%
 */
export const STAMP_DUTY_RATES: Record<BuyerCategory, number> = {
  male: 0.07,
  female: 0.06,
  joint_male_female: 0.065,
  joint_male_male: 0.07,
  joint_female_female: 0.06,
} as const;

/**
 * Registration fee rate under UP Registration Rules
 * 1% of property valuation (flat across all categories)
 */
export const REGISTRATION_FEE_RATE = 0.01;

/**
 * Unit conversion helper functions
 * Converts any area unit to Square Metres (standard for Plots)
 * and to Hectares (standard for Agricultural land).
 */
export function convertToSqMetres(area: number, unit: AreaUnit): number {
  if (!area || area <= 0) return 0;

  switch (unit) {
    case 'sq_m':
      return area;
    case 'sq_ft':
      return area / KANPUR_REVENUE_FACTORS.SQ_FT_PER_SQ_METRE;
    case 'biswa':
      // 1 Biswa = 1,125 sq. ft => in sq. m = (area * 1125) / 10.764
      return (area * KANPUR_REVENUE_FACTORS.SQ_FT_PER_BISWA) / KANPUR_REVENUE_FACTORS.SQ_FT_PER_SQ_METRE;
    case 'bigha':
      // 1 Pucca Bigha = 22,500 sq. ft => in sq. m = (area * 22500) / 10.764
      return (area * KANPUR_REVENUE_FACTORS.SQ_FT_PER_PUCCA_BIGHA) / KANPUR_REVENUE_FACTORS.SQ_FT_PER_SQ_METRE;
    case 'hectare':
      // 1 Hectare = 10,000 sq. m
      return area * KANPUR_REVENUE_FACTORS.SQ_METRES_PER_HECTARE;
    case 'acre':
      // 1 Acre = 4,046.86 sq. m
      return area * KANPUR_REVENUE_FACTORS.SQ_METRES_PER_ACRE;
    default:
      return area;
  }
}

export function convertToHectares(sqMetres: number): number {
  return sqMetres / KANPUR_REVENUE_FACTORS.SQ_METRES_PER_HECTARE;
}

export function convertToSqFeet(sqMetres: number): number {
  return sqMetres * KANPUR_REVENUE_FACTORS.SQ_FT_PER_SQ_METRE;
}

export function convertToBiswa(sqMetres: number): number {
  const sqFeet = convertToSqFeet(sqMetres);
  return sqFeet / KANPUR_REVENUE_FACTORS.SQ_FT_PER_BISWA;
}

export function convertToPuccaBigha(sqMetres: number): number {
  const sqFeet = convertToSqFeet(sqMetres);
  return sqFeet / KANPUR_REVENUE_FACTORS.SQ_FT_PER_PUCCA_BIGHA;
}

export function convertToAcres(sqMetres: number): number {
  return sqMetres / KANPUR_REVENUE_FACTORS.SQ_METRES_PER_ACRE;
}

/**
 * Format currency in Indian numbering system (e.g. ₹ 15,25,000)
 * Note: Always rounds up to the top whole rupee (ceiling rule: 50.0123 -> 51)
 */
export function formatINR(amount: number): string {
  if (isNaN(amount)) return '₹0';
  const rounded = Math.ceil(amount);
  return `₹${rounded.toLocaleString('en-IN')}`;
}

/**
 * Format currency into Indian spoken words (Rupees ... Only)
 */
export function formatIndianCurrencyWords(amount: number, lang: 'en' | 'hi' = 'en'): string {
  if (!amount || amount <= 0) return lang === 'hi' ? 'शून्य रुपये मात्र' : 'Zero Rupees Only';
  const n = Math.ceil(amount);

  const unitsEn = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tensEn = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function convertBelowThousand(val: number): string {
    let str = '';
    if (val >= 100) {
      str += unitsEn[Math.floor(val / 100)] + ' Hundred ';
      val %= 100;
    }
    if (val > 0) {
      if (val < 20) {
        str += unitsEn[val] + ' ';
      } else {
        str += tensEn[Math.floor(val / 10)] + (val % 10 > 0 ? ' ' + unitsEn[val % 10] : '') + ' ';
      }
    }
    return str.trim();
  }

  if (lang === 'en') {
    let remaining = n;
    const parts: string[] = [];

    const crore = Math.floor(remaining / 10000000);
    remaining %= 10000000;
    if (crore > 0) parts.push(convertBelowThousand(crore) + ' Crore');

    const lakh = Math.floor(remaining / 100000);
    remaining %= 100000;
    if (lakh > 0) parts.push(convertBelowThousand(lakh) + ' Lakh');

    const thousand = Math.floor(remaining / 1000);
    remaining %= 1000;
    if (thousand > 0) parts.push(convertBelowThousand(thousand) + ' Thousand');

    const hundred = convertBelowThousand(remaining);
    if (hundred) parts.push(hundred);

    return 'Rupees ' + parts.join(' ') + ' Only';
  } else {
    const lkCr = formatLakhCrore(n, 'hi');
    return `${formatINR(n)} रुपये ${lkCr ? ` ${lkCr}` : ''} मात्र`;
  }
}

/**
 * Format numbers with appropriate decimal places for clean reading
 */
export function formatNumber(val: number, decimals: number = 2): string {
  if (isNaN(val)) return '0';
  if (Number.isInteger(val)) return val.toLocaleString('en-IN');
  return Number(val.toFixed(decimals)).toLocaleString('en-IN', {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  });
}

/**
 * Express amount in Indian words/shorthand (Lakh / Crore)
 */
export function formatLakhCrore(amount: number, lang: 'en' | 'hi' = 'en'): string {
  if (!amount || amount <= 0) return '';
  const rounded = Math.ceil(amount);
  if (rounded >= 10000000) {
    const cr = (rounded / 10000000).toFixed(2);
    return lang === 'hi' ? `(लगभग ₹${cr} करोड़)` : `(~₹${cr} Cr)`;
  }
  if (rounded >= 100000) {
    const lk = (rounded / 100000).toFixed(2);
    return lang === 'hi' ? `(लगभग ₹${lk} लाख)` : `(~₹${lk} Lakh)`;
  }
  if (rounded >= 1000) {
    const th = (rounded / 1000).toFixed(1);
    return lang === 'hi' ? `(₹${th} हजार)` : `(~₹${th}k)`;
  }
  return '';
}

/**
 * Bilingual UI Text Dictionary
 */
export const TRANSLATIONS = {
  en: {
    appTitle: "Advocate Soofiyan's Stamp Duty & Registration Fee Calculator",
    appSubtitle: 'Kanpur Nagar & Kanpur Dehat Revenue & Registration Estimation Tool',
    estimationBadge: 'Estimation Tool (Non-Official)',
    districtNotice: 'Based on Awadh/Doab Kanpur Revenue Standard (1 Pucca Bigha = 22,500 sq. ft = 20 Biswa)',
    langToggleLabel: 'हिंदी में देखें',
    
    // Form Labels
    propertyType: 'Property Type',
    plotOption: 'Residential / Commercial Plot',
    agriculturalOption: 'Agricultural Land (कृषि भूमि)',
    
    // Locality / Village / Area
    localityLabel: 'Village / Area / Locality',
    localityPlaceholder: 'Enter Village, Area, Locality or Mauza (e.g. Swaroop Nagar)',
    localityHelp: 'Revenue village (Mauza), ward, mohalla, or colony in Kanpur',
    localitySummary: 'Village / Locality',
    
    // Dimension Calculator (Length * Height = Area)
    dimensionSectionTitle: 'Calculate Area from Dimensions (Length × Height)',
    dimensionCheckboxLabel: 'Calculate area from Length × Height (L × H = Area)',
    dimensionCheckboxSubtext: 'Check if you have plot length and height measurements in feet or metres',
    dimensionLengthLabel: 'Length',
    dimensionHeightLabel: 'Height / Width',
    dimensionLengthPlaceholder: 'e.g. 50',
    dimensionHeightPlaceholder: 'e.g. 20',
    dimensionUnitLabel: 'Measurement Unit',
    dimensionUnitFeet: 'Feet (ft) → Sq. Feet',
    dimensionUnitMeter: 'Metre (m) → Sq. Metre',
    dimensionResultFormula: 'Area = Length × Height',
    dimensionRawArea: 'Exact Area',
    dimensionTopRoundedArea: 'Ceiling Rounded Area (Top Value)',
    topRoundingBadge: 'Always rounded to top value (e.g. 50.01 → 51)',
    topRoundingExplainer: 'As per UP registration conventions, all area valuations and payable fees are rounded up to the nearest top whole integer.',
    
    areaValue: 'Area / Land Size',
    areaPlaceholder: 'Enter numeric area (e.g. 1000 or 2.5)',
    areaUnit: 'Area Unit',
    
    unitLabels: {
      sq_ft: 'Square Feet (sq. ft)',
      sq_m: 'Square Metre (sq. m)',
      biswa: 'Biswa (1,125 sq. ft)',
      bigha: 'Bigha (Pucca - 22,500 sq. ft / 20 Biswa)',
      hectare: 'Hectare (10,000 sq. m)',
      acre: 'Acre (4,046.86 sq. m)',
    },
    
    circleRateLabelPlot: 'Government Circle Rate (per Square Metre)',
    circleRateLabelAgri: 'Government Circle Rate (per Hectare)',
    circleRatePlaceholderPlot: 'Enter rate in ₹ per sq. metre',
    circleRatePlaceholderAgri: 'Enter rate in ₹ per hectare',
    circleRateHelpPlot: 'Official DM Circle Rate prescribed per sq. metre for this locality/mohalla',
    circleRateHelpAgri: 'Official DM Circle Rate prescribed per hectare for this mauza/village',
    
    declaredPriceLabel: 'Declared / Agreement Sale Price',
    declaredPriceOptional: '(Optional)',
    declaredPricePlaceholder: 'Enter actual agreed sale price if higher than circle rate',
    declaredPriceHelp: 'Under Section 47A, duty is levied on the HIGHER of Circle Rate Value vs Declared Sale Consideration',
    
    buyerCategory: 'Buyer Category (Stamp Duty Slab)',
    buyerOptions: {
      male: 'Male (Sole Buyer) — 7%',
      female: 'Female (Sole Buyer) — 6% (Includes 1% UP Govt rebate)',
      joint_male_female: 'Joint (Male + Female) — 6.5%',
      joint_male_male: 'Joint (Male + Male) — 7%',
      joint_female_female: 'Joint (Female + Female) — 6%',
    },

    // Registration Fee Rate Option (1% to 5%)
    registrationFeeRateLabel: 'Registration Fee Rate',
    registrationFeeRateHelp: 'Default statutory fee in UP is 1%. Select or vary between 1% to 5% as required.',
    registrationFeeStandard: '1% (Standard UP Statutory Rate)',
    
    // Sanity check banner
    convertedAreaSanity: 'Sanity Check: Converted Area',
    convertedEquivalents: 'Equivalent Area Breakdown:',
    
    // Results
    breakdownTitle: 'Valuation & Fee Breakdown',
    breakdownSubtitle: 'Calculated in accordance with UP Stamp Act & Registration Rules',
    convertedAreaLabel: 'Converted Area for Valuation',
    circleRateAssessedValue: 'Circle Rate Assessed Value',
    declaredPriceProvided: 'Declared Agreement Sale Price',
    propertyValueUsed: 'Taxable Property Valuation',
    valuationBasisCircle: 'Based on Government Circle Rate (higher than declared price)',
    valuationBasisDeclared: 'Based on Declared Sale Price (higher than circle rate value)',
    valuationBasisEqual: 'Both Circle Rate and Declared Price are identical',
    
    stampDuty: 'Stamp Duty Payable',
    stampDutyRateText: 'Rate applied based on buyer category',
    registrationFee: 'Registration Fee',
    registrationFeeText: 'Mandatory statutory fee payable at Sub-Registrar Office',
    totalPayable: 'Total Government Dues Payable',
    totalPayableSubtext: 'Stamp Duty + Registration Fee (exclusive of advocate/clerical charges)',
    
    // Purchaser Expenses Section
    expensesSectionTitle: "Purchaser's Incidental & Registration Expenses",
    expensesSectionSubtitle: 'Statutory deed drafting, typing, online filing, and verification expenses payable by the purchaser',
    expensesIncludeCheckbox: 'Include Purchaser Incidental Registration Expenses',
    expTypingOnline: 'Type, online etc.',
    expTypingOnlineDesc: 'Deed typing, online IGRS portal filing, token generation',
    expAudit: 'Audit',
    expAuditDesc: 'Valuation scrutiny, audit & registry record verification',
    expAdvocateFee: "Advocate's fee",
    expAdvocateFeeDesc: 'Title verification, deed drafting & legal consultation',
    expGpsPhoto: 'GPS photo',
    expGpsPhotoDesc: 'Mandatory geo-tagged coordinates photo of the plot/property',
    expCertification: 'Certification',
    expCertificationDesc: 'Deed witness identification & advocate certification',
    expNaqshaNazari: 'Naqsha Nazari',
    expNaqshaNazariDesc: 'Site boundary plan / property visual layout drawing',
    
    govtDuesSubtotal: 'Subtotal: Government Dues',
    purchaserExpensesSubtotal: 'Subtotal: Purchaser Expenses',
    grandTotalPayable: 'Grand Total Expenses from Purchaser',
    grandTotalSubtext: 'Total outflow from purchaser: Government Dues (Stamp Duty + Reg Fee) + Incidental Expenses',
    
    femaleBenefitBadge: 'Female Buyer Concession Applied (Saved 1% on Stamp Duty)',
    jointFemaleBenefitBadge: 'Joint Concession Applied (Saved 0.5% on Stamp Duty)',
    
    // Preset examples
    presetTitle: 'Quick Fill Examples:',
    presetPlot: '1,000 sq ft Plot (Swaroop Nagar / Kalyanpur)',
    presetAgri: '1 Pucca Bigha Farm Land (Kanpur Dehat)',
    clearForm: 'Reset Form',
    copySummary: 'Copy Estimate Summary',
    summaryCopied: 'Estimate Copied to Clipboard!',
    printEstimate: 'Print Breakdown',
    printEstimateSecondary: 'Print Breakdown Slip / Save as PDF',
    printSlipTitle: 'Kanpur Stamp Duty & Registration Fee Calculation Slip',
    printOfficeTitle: 'Office of Advocate A. Soofiyan',
    printOfficeSub: 'Advocate & Legal Consultant • Kanpur Nagar & Kanpur Dehat',
    printAssessedUnder: 'Estimated under Section 47-A of the Indian Stamp Act, 1899 & UP Registration Rules',
    printGeneratedDate: 'Assessment Date',
    printPropertyDetailsTitle: 'Property & Assessment Particulars',
    printFeeTableTitle: 'Statutory Stamp Duty & Registration Fee Schedule',
    printParticulars: 'Particulars',
    printAssessedRate: 'Rate Applied',
    printCalculatedDues: 'Statutory Dues (₹)',
    printTotalPayableWords: 'Amount in Words',
    printLegalNoticeTitle: 'Statutory Disclaimer & Advisory Notice',
    printSignAdvocate: 'Advocate A. Soofiyan (Seal & Signature)',
    printSignClient: 'Client / Purchaser Acknowledgment',
    printRevenueStandard: 'Standard Applied: Awadh / Doab Revenue (1 Pucca Bigha = 22,500 sq ft = 20 Biswa)',
    
    // Disclaimer & Footer
    disclaimerTitle: 'Mandatory Disclaimer & Legal Notice',
    disclaimerText: 'This is an estimate only, based on current published rates. Stamp duty rates, registration fees, and circle rates are subject to change by Government notification. Please verify current figures on the IGRS UP portal (igrsup.gov.in) or confirm with your Sub-Registrar office / advocate before proceeding with registration.',
    verifyOnIgrs: 'Verify official rates on IGRS UP Portal (igrsup.gov.in)',
    footerLine: 'Calculator by Advocate A. Soofiyan — Kanpur',
    kanpurRevenueNoteTitle: 'Kanpur Revenue Note (Pucca Bigha vs Kacha Bigha)',
    kanpurRevenueNoteText: 'In the Kanpur region (Awadh/Doab registry division), 1 Bigha (Pucca) is legally standardized at 20 Biswa = 22,500 Sq. Ft (approx 2,090.3 Sq. Metres). This is distinct from western UP (Meerut/Bulandshahr) where 1 Bigha is often 6,800 or 9,075 Sq. Ft.',
  },
  
  hi: {
    appTitle: 'एडवोकेट सूफियान का स्टाम्प शुल्क एवं निबंधन शुल्क कैलकुलेटर',
    appSubtitle: 'कानपुर नगर एवं कानपुर देहात — रजिस्ट्री शुल्क अनुमानक उपकरण',
    estimationBadge: 'अनुमानक उपकरण (गैर-आधिकारिक)',
    districtNotice: 'अवध/दोआब कानपुर राजस्व मानक आधारित (1 पक्का बीघा = 22,500 वर्ग फुट = 20 बिस्वा)',
    langToggleLabel: 'View in English',
    
    // Form Labels
    propertyType: 'संपत्ति का प्रकार',
    plotOption: 'आवासीय / व्यावसायिक भूखंड (Plot)',
    agriculturalOption: 'कृषि भूमि (Agricultural Land)',
    
    // Locality / Village / Area
    localityLabel: 'ग्राम / क्षेत्र / मोहल्ला (Village / Area / Locality)',
    localityPlaceholder: 'ग्राम, मौजा, क्षेत्र या मोहल्ले का नाम दर्ज करें (उदा. स्वरूप नगर)',
    localityHelp: 'कानपुर राजस्व क्षेत्र का मौजा, वार्ड, कॉलोनी या मोहल्ला',
    localitySummary: 'ग्राम / क्षेत्र / मोहल्ला',
    
    // Dimension Calculator (Length * Height = Area)
    dimensionSectionTitle: 'नाप से क्षेत्रफल की गणना (लंबाई × ऊंचाई)',
    dimensionCheckboxLabel: 'लंबाई × ऊंचाई से क्षेत्रफल निकालें (Length × Height = Area)',
    dimensionCheckboxSubtext: 'यदि आपके पास भूखंड की लंबाई एवं चौड़ाई/ऊंचाई की नाप है तो टिक करें',
    dimensionLengthLabel: 'लंबाई (Length)',
    dimensionHeightLabel: 'ऊंचाई / चौड़ाई (Height / Width)',
    dimensionLengthPlaceholder: 'उदा. 50',
    dimensionHeightPlaceholder: 'उदा. 20',
    dimensionUnitLabel: 'माप की इकाई',
    dimensionUnitFeet: 'फुट (Feet) → वर्ग फुट में गणना',
    dimensionUnitMeter: 'मीटर (Metre) → वर्ग मीटर में गणना',
    dimensionResultFormula: 'क्षेत्रफल = लंबाई × ऊंचाई',
    dimensionRawArea: 'सटीक क्षेत्रफल',
    dimensionTopRoundedArea: 'शीर्ष मान में पूर्णांकित क्षेत्रफल (Top Value)',
    topRoundingBadge: 'सदैव शीर्ष मान में पूर्णांकित (उदा. 50.01 → 51)',
    topRoundingExplainer: 'उ.प्र. रजिस्ट्री परिपाटी के अनुसार क्षेत्रफल एवं समस्त देय सरकारी शुल्क अगले शीर्ष पूर्णांक मान पर संगणित होते हैं।',
    
    areaValue: 'क्षेत्रफल / जमीन का आकार',
    areaPlaceholder: 'संख्यात्मक मान दर्ज करें (उदा. 1000 या 2.5)',
    areaUnit: 'क्षेत्रफल की इकाई (Unit)',
    
    unitLabels: {
      sq_ft: 'वर्ग फुट (Square Feet)',
      sq_m: 'वर्ग मीटर (Square Metre)',
      biswa: 'बिस्वा (1,125 वर्ग फुट)',
      bigha: 'पक्का बीघा (22,500 वर्ग फुट / 20 बिस्वा)',
      hectare: 'हेक्टेयर (10,000 वर्ग मीटर)',
      acre: 'एकड़ (4,046.86 वर्ग मीटर)',
    },
    
    circleRateLabelPlot: 'सरकारी सर्किल रेट (प्रति वर्ग मीटर)',
    circleRateLabelAgri: 'सरकारी सर्किल रेट (प्रति हेक्टेयर)',
    circleRatePlaceholderPlot: '₹ प्रति वर्ग मीटर में दर दर्ज करें',
    circleRatePlaceholderAgri: '₹ प्रति हेक्टेयर में दर दर्ज करें',
    circleRateHelpPlot: 'इस मोहल्ले/वार्ड हेतु निर्धारित उप-निबंधक सर्किल दर',
    circleRateHelpAgri: 'इस मौजा/ग्राम हेतु निर्धारित प्रति हेक्टेयर सर्किल दर',
    
    declaredPriceLabel: 'घोषित / इकरारनामा विक्रय मूल्य',
    declaredPriceOptional: '(वैकल्पिक)',
    declaredPricePlaceholder: 'यदि सर्किल रेट मूल्यांकन से अधिक तय हुआ हो तो दर्ज करें',
    declaredPriceHelp: 'धारा 47A के अनुसार: सर्किल रेट मूल्य एवं घोषित मूल्य में जो भी अधिक हो, उस पर स्टाम्प शुल्क देय होता है।',
    
    buyerCategory: 'क्रेता वर्ग (स्टाम्प शुल्क दर)',
    buyerOptions: {
      male: 'पुरुष (एकल क्रेता) — 7%',
      female: 'महिला (एकल क्रेता) — 6% (उ.प्र. शासन द्वारा 1% की छूट सम्मिलित)',
      joint_male_female: 'संयुक्त (पुरुष + महिला) — 6.5%',
      joint_male_male: 'संयुक्त (पुरुष + पुरुष) — 7%',
      joint_female_female: 'संयुक्त (महिला + महिला) — 6%',
    },

    // Registration Fee Rate Option (1% to 5%)
    registrationFeeRateLabel: 'निबंधन / रजिस्ट्री शुल्क दर',
    registrationFeeRateHelp: 'उ.प्र. रजिस्ट्री नियमावली के अंतर्गत मानक शुल्क 1% है। आवश्यकतानुसार 1% से 5% तक चुनें।',
    registrationFeeStandard: '1% (मानक उ.प्र. दर)',
    
    // Sanity check banner
    convertedAreaSanity: 'सटीकता जांच: परिवर्तित क्षेत्रफल',
    convertedEquivalents: 'अन्य इकाइयों में समतुल्य क्षेत्रफल:',
    
    // Results
    breakdownTitle: 'मूल्यांकन एवं शुल्क विवरण',
    breakdownSubtitle: 'उ.प्र. स्टाम्प अधिनियम व निबंधन नियमावली के अनुरूप संगणित',
    convertedAreaLabel: 'मूल्यांकन हेतु परिवर्तित क्षेत्रफल',
    circleRateAssessedValue: 'सर्किल रेट आधारित न्यूनतम मूल्यांकन',
    declaredPriceProvided: 'घोषित / तयशुदा विक्रय मूल्य',
    propertyValueUsed: 'कर-योग्य संपत्ति मूल्यांकन (Property Value)',
    valuationBasisCircle: 'सर्किल रेट मूल्य पर आधारित (घोषित मूल्य से अधिक या समान)',
    valuationBasisDeclared: 'घोषित विक्रय मूल्य पर आधारित (सर्किल रेट से अधिक)',
    valuationBasisEqual: 'सर्किल रेट और घोषित मूल्य दोनों एक समान हैं',
    
    stampDuty: 'देय स्टाम्प शुल्क (Stamp Duty)',
    stampDutyRateText: 'क्रेता श्रेणी के अनुसार लागू दर',
    registrationFee: 'निबंधन / रजिस्ट्री शुल्क',
    registrationFeeText: 'उप-निबंधक कार्यालय में देय वैधानिक शुल्क',
    totalPayable: 'कुल देय सरकारी शुल्क (Total Payable)',
    totalPayableSubtext: 'स्टाम्प शुल्क + रजिस्ट्री शुल्क (अधिवक्ता/ड्राफ्टिंग व्यय अतिरिक्त)',
    
    // Purchaser Expenses Section
    expensesSectionTitle: 'क्रेता के विविध एवं निबंधन व्यय',
    expensesSectionSubtitle: 'विलेख प्रारूपण, टाइपिंग, ऑनलाइन दाखिल व प्रमाणीकरण हेतु क्रेता द्वारा देय विविध व्यय',
    expensesIncludeCheckbox: 'क्रेता के विविध रजिस्ट्री व्यय सम्मिलित करें',
    expTypingOnline: 'टाइपिंग, ऑनलाइन आदि (Type, Online etc.)',
    expTypingOnlineDesc: 'विलेख टाइपिंग, आई.जी.आर.एस. ऑनलाइन आवेदन व टोकन शुल्क',
    expAudit: 'ऑडिट (Audit)',
    expAuditDesc: 'राजस्व मूल्यांकन परीक्षण एवं लेखा जांच',
    expAdvocateFee: 'अधिवक्ता शुल्क (Advocate\'s Fee)',
    expAdvocateFeeDesc: 'विलेख प्रारूपण, विधिक परीक्षण एवं परामर्श शुल्क',
    expGpsPhoto: 'जी.पी.एस. फोटो (GPS Photo)',
    expGpsPhotoDesc: 'शासनादेशानुसार भूखंड की अक्षांश-देशांतर जियो-टैग फोटो',
    expCertification: 'प्रमाणीकरण (Certification)',
    expCertificationDesc: 'अधिवक्ता सत्यापन एवं विधिक प्रमाणीकरण',
    expNaqshaNazari: 'नजरी नक्शा (Naqsha Nazari)',
    expNaqshaNazariDesc: 'चौहद्दी दर्शाने वाला नजरी नक्शा व साइट प्लान',
    
    govtDuesSubtotal: 'सरकारी शुल्क उप-योग (स्टाम्प + रजिस्ट्री)',
    purchaserExpensesSubtotal: 'क्रेता विविध व्यय उप-योग',
    grandTotalPayable: 'क्रेता द्वारा देय कुल सकल व्यय (Grand Total)',
    grandTotalSubtext: 'क्रेता की जेब से कुल खर्च (सरकारी स्टाम्प व रजिस्ट्री शुल्क + समस्त विविध व्यय)',
    
    femaleBenefitBadge: 'महिला छूट लागू (स्टाम्प शुल्क में 1% की बचत)',
    jointFemaleBenefitBadge: 'संयुक्त महिला छूट लागू (स्टाम्प शुल्क में 0.5% की बचत)',
    
    // Preset examples
    presetTitle: 'त्वरित उदाहरण भरें:',
    presetPlot: '1,000 वर्ग फुट भूखंड (स्वरूप नगर / कल्याणपुर)',
    presetAgri: '1 पक्का बीघा कृषि भूमि (कानपुर देहात)',
    clearForm: 'फॉर्म रीसेट करें',
    copySummary: 'विवरण कॉपी करें',
    summaryCopied: 'विवरण क्लिपबोर्ड पर कॉपी हो गया!',
    printEstimate: 'प्रिंट करें',
    printEstimateSecondary: 'आगणन पर्ची प्रिंट करें / PDF सहेजें',
    printSlipTitle: 'कानपुर स्टाम्प शुल्क एवं निबंधन शुल्क आगणन पर्ची',
    printOfficeTitle: 'एडवोकेट ए. सूफियान का कार्यालय',
    printOfficeSub: 'अधिवक्ता एवं विधिक सलाहकार • कानपुर नगर एवं कानपुर देहात',
    printAssessedUnder: 'भारतीय स्टाम्प अधिनियम 1899 की धारा 47-A व उ.प्र. निबंधन नियमावली के अंतर्गत आगणित',
    printGeneratedDate: 'आगणन दिनांक',
    printPropertyDetailsTitle: 'संपत्ति एवं मूल्यांकन विवरण',
    printFeeTableTitle: 'वैधानिक स्टाम्प शुल्क व रजिस्ट्री शुल्क तालिका',
    printParticulars: 'विवरण',
    printAssessedRate: 'लागू दर',
    printCalculatedDues: 'देय शुल्क (₹)',
    printTotalPayableWords: 'शब्दों में धनराशि',
    printLegalNoticeTitle: 'वैधानिक कानूनी सूचना एवं अस्वीकरण',
    printSignAdvocate: 'एडवोकेट ए. सूफियान (मुहर व हस्ताक्षर)',
    printSignClient: 'क्रेता / मुवक्किल के हस्ताक्षर',
    printRevenueStandard: 'मानक प्रयुक्त: अवध/दोआब राजस्व मानक (1 पक्का बीघा = 22,500 वर्ग फुट = 20 बिस्वा)',
    
    // Disclaimer & Footer
    disclaimerTitle: 'अनिवार्य अस्वीकरण एवं कानूनी सूचना',
    disclaimerText: 'This is an estimate only, based on current published rates. Stamp duty rates, registration fees, and circle rates are subject to change by Government notification. Please verify current figures on the IGRS UP portal (igrsup.gov.in) or confirm with your Sub-Registrar office / advocate before proceeding with registration.',
    verifyOnIgrs: 'आई.जी.आर.एस. पोर्टल पर आधिकारिक दरें जांचें (igrsup.gov.in)',
    footerLine: 'Calculator by Advocate A. Soofiyan — Kanpur',
    kanpurRevenueNoteTitle: 'कानपुर राजस्व मानक टिप्पणी (पक्का बीघा बनाम कच्चा बीघा)',
    kanpurRevenueNoteText: 'कानपुर मंडल (अवध/दोआब रजिस्ट्री क्षेत्र) में 1 पक्का बीघा = 20 बिस्वा = 22,500 वर्ग फुट (लगभग 2,090.3 वर्ग मीटर) मान्य है। यह पश्चिमी उत्तर प्रदेश के कच्चे बीघे (6,800 या 9,075 वर्ग फुट) से भिन्न है।',
  },
} as const;
