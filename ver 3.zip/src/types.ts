export type PropertyType = 'plot' | 'agricultural';

export type AreaUnit =
  | 'sq_ft'
  | 'sq_m'
  | 'biswa'
  | 'bigha'
  | 'hectare'
  | 'acre';

export type BuyerCategory =
  | 'male'
  | 'female'
  | 'joint_male_female'
  | 'joint_male_male'
  | 'joint_female_female';

export type Language = 'en' | 'hi';

export type DimensionUnit = 'feet' | 'meter';

export interface PurchaserExpenses {
  typingOnline: number; // type, online etc - 1200 Rs
  audit: number; // Audit - 1000Rs
  advocateFee: number; // Advocate's fee - 1500Rs
  gpsPhoto: number; // GPS photo - 100Rs
  certification: number; // Certification - 1500Rs
  naqshaNazari: number; // Naqsha Nazari - 1000Rs
}

export interface CalculationInput {
  propertyType: PropertyType;
  // Locality / Village / Area
  localityName: string;
  areaValue: number | '';
  areaUnit: AreaUnit;
  circleRate: number | '';
  declaredPrice: number | '';
  buyerCategory: BuyerCategory;
  // Registration Fee percentage option (1% to 5%)
  registrationFeePercent: number;
  // Dimension Calculator (Length * Height = Area)
  dimensionCalcEnabled: boolean;
  dimensionLength: number | '';
  dimensionHeight: number | '';
  dimensionUnit: DimensionUnit;
  // Purchaser registration & incidental expenses
  includeExpenses: boolean;
  expenses: PurchaserExpenses;
}

export interface AreaConversionResult {
  sqMetres: number;
  sqFeet: number;
  hectares: number;
  biswa: number;
  bighaPucca: number;
  acres: number;
  displayFormattedPrimary: string;
  displayFormattedSecondary: string;
}

export interface CalculationResult {
  convertedAreaSqM: number;
  convertedAreaHectares: number;
  circleRateApplicableArea: number; // sq m for plot, hectare for agricultural
  circleRateUnitLabel: string;
  circleRateValue: number;
  declaredPrice: number;
  propertyValue: number;
  valuationBasis: 'circle_rate' | 'declared_price';
  stampDutyRate: number; // e.g. 0.07
  stampDutyAmount: number;
  registrationFeeRate: number; // e.g. 0.01, 0.02, 0.03, 0.04, 0.05
  registrationFeePercent: number; // 1, 2, 3, 4, 5 (%)
  registrationFeeAmount: number;
  governmentDues: number; // stampDutyAmount + registrationFeeAmount
  totalExpenses: number; // sum of purchaser expenses
  itemizedExpenses: PurchaserExpenses;
  grandTotal: number; // governmentDues + totalExpenses
  totalPayable: number; // grand total expenses from the purchaser
  femaleConcessionApplied: boolean;
}
