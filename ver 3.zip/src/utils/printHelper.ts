/**
 * Robust cross-browser and iframe-safe printing utilities.
 * Handles sandboxed environments, iframe restrictions, and pop-up blockers.
 */

/**
 * Prints HTML content via a hidden iframe to isolate print styles from the main app.
 * Falls back to standard window.print() if iframe creation/printing is restricted.
 */
export function printHtmlViaHiddenIframe(htmlContent: string): Promise<boolean> {
  return new Promise((resolve) => {
    try {
      // Remove any existing print iframe
      const existingIframe = document.getElementById('print-sandbox-frame');
      if (existingIframe) {
        document.body.removeChild(existingIframe);
      }

      const iframe = document.createElement('iframe');
      iframe.id = 'print-sandbox-frame';
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = 'none';
      iframe.style.zIndex = '-9999';
      iframe.style.visibility = 'hidden';

      document.body.appendChild(iframe);

      const frameDoc = iframe.contentWindow?.document || iframe.contentDocument;
      if (!frameDoc) {
        throw new Error('Unable to access iframe document');
      }

      frameDoc.open();
      frameDoc.write(htmlContent);
      frameDoc.close();

      // Give styles and fonts a moment to evaluate
      const triggerPrint = () => {
        try {
          if (iframe.contentWindow) {
            iframe.contentWindow.focus();
            iframe.contentWindow.print();
            resolve(true);
          } else {
            throw new Error('No content window');
          }
        } catch (err) {
          console.warn('Iframe print failed, falling back to window.print():', err);
          try {
            window.print();
            resolve(true);
          } catch (winErr) {
            console.error('window.print() also failed:', winErr);
            resolve(false);
          }
        } finally {
          // Cleanup after printing dialog closes or after delay
          setTimeout(() => {
            try {
              if (document.body.contains(iframe)) {
                document.body.removeChild(iframe);
              }
            } catch {
              // ignore
            }
          }, 30000);
        }
      };

      if (iframe.contentWindow?.document.readyState === 'complete') {
        setTimeout(triggerPrint, 300);
      } else {
        iframe.onload = () => {
          setTimeout(triggerPrint, 300);
        };
      }
    } catch (e) {
      console.warn('Failed to print via iframe, falling back to window.print():', e);
      try {
        window.print();
        resolve(true);
      } catch (err) {
        console.error('Standard window.print() failed:', err);
        resolve(false);
      }
    }
  });
}

/**
 * Downloads the printable slip as a standalone, offline-viewable HTML file.
 * Guaranteed to work regardless of iframe restrictions or popup blockers.
 */
export function downloadSlipAsHtml(htmlContent: string, fileName: string): boolean {
  try {
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName.endsWith('.html') ? fileName : `${fileName}.html`;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    return true;
  } catch (err) {
    console.error('Failed to download slip HTML:', err);
    return false;
  }
}
