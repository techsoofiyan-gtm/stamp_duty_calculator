import { CalculationInput, CalculationResult, Language, PropertyType } from '../types';
import {
  formatINR,
  formatNumber,
  formatLakhCrore,
  formatIndianCurrencyWords,
  convertToSqFeet,
  convertToBiswa,
  convertToPuccaBigha,
  convertToAcres,
  TRANSLATIONS,
} from '../constants/stampDutyConfig';

export function generatePrintableSlipHtml(
  results: CalculationResult,
  input: CalculationInput,
  propertyType: PropertyType,
  language: Language,
  qrDataUrl?: string
): string {
  const t = TRANSLATIONS[language];
  const isPlot = propertyType === 'plot';

  const now = new Date();
  const printDateStr = now.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
  const printTimeStr = now.toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  const refCode = `SOOF-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}-${String(Math.floor(1000 + Math.random() * 9000))}`;

  const unitLabel = t.unitLabels[input.areaUnit] || input.areaUnit;
  const buyerCategoryLabel = t.buyerOptions[input.buyerCategory] || input.buyerCategory;

  const sqFeet = convertToSqFeet(results.convertedAreaSqM);
  const biswa = convertToBiswa(results.convertedAreaSqM);
  const puccaBigha = convertToPuccaBigha(results.convertedAreaSqM);
  const acres = convertToAcres(results.convertedAreaSqM);

  const dimensionText =
    input.dimensionCalcEnabled && input.dimensionLength && input.dimensionHeight
      ? `${input.dimensionLength} × ${input.dimensionHeight} ${input.dimensionUnit === 'feet' ? 'ft' : 'm'} = ${formatNumber(input.dimensionUnit === 'feet' ? sqFeet : results.convertedAreaSqM, 0)} ${input.dimensionUnit === 'feet' ? 'sq. ft' : 'sq. m'}`
      : `${input.areaValue} ${unitLabel}`;

  return `<!DOCTYPE html>
<html lang="${language}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${t.printSlipTitle} - Advocate A. Soofiyan | soofiyan.com</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    html, body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      background-color: #181a20;
      color: #18181b;
      line-height: 1.3;
      font-size: 9.5px;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }

    /* Screen Action Bar */
    .top-action-bar {
      max-width: 210mm;
      margin: 12px auto 10px auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #111318;
      color: #f4f4f5;
      padding: 10px 16px;
      border-radius: 8px;
      border: 1px solid #27272a;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      font-size: 12px;
    }
    .btn-print {
      background: #d97706;
      color: #ffffff;
      border: none;
      padding: 8px 18px;
      font-weight: 800;
      border-radius: 6px;
      cursor: pointer;
      font-size: 12.5px;
      letter-spacing: 0.2px;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      box-shadow: 0 2px 6px rgba(217, 119, 6, 0.4);
    }
    .btn-print:hover { background: #b45309; }

    /* Single A4 Paper Container: Calibrated to 283mm so that ALL space is used and NO second page is ever generated */
    .paper-container {
      width: 210mm;
      max-width: 210mm;
      height: 283mm;
      min-height: 283mm;
      max-height: 283mm;
      margin: 0 auto 20px auto;
      background: #ffffff;
      padding: 7mm 8mm;
      border: 1px solid #a1a1aa;
      border-radius: 4px;
      box-shadow: 0 6px 24px rgba(0,0,0,0.4);
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      overflow: hidden;
      page-break-inside: avoid;
      page-break-after: avoid;
      break-inside: avoid;
      break-after: avoid;
    }

    /* 1. Header Section */
    .header-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 2px solid #09090b;
      padding-bottom: 6px;
      gap: 12px;
    }

    .chamber-brand {
      display: flex;
      flex-direction: column;
      gap: 1.5px;
    }

    .chamber-title {
      font-family: Georgia, serif;
      font-size: 15.5px;
      font-weight: 900;
      letter-spacing: 0.4px;
      color: #09090b;
      text-transform: uppercase;
    }

    .chamber-sub {
      font-size: 10px;
      color: #27272a;
      font-weight: 700;
    }

    .chamber-court {
      font-size: 8.5px;
      color: #52525b;
      font-weight: 500;
    }

    .brand-pill {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      background: #fef3c7;
      color: #92400e;
      border: 1px solid #f59e0b;
      font-weight: 800;
      font-size: 9px;
      padding: 1.5px 7px;
      border-radius: 3px;
      margin-top: 2px;
      letter-spacing: 0.3px;
    }

    /* QR Code Box */
    .qr-container {
      display: flex;
      align-items: center;
      gap: 8px;
      background: #fafafa;
      border: 1px solid #d4d4d8;
      border-radius: 6px;
      padding: 4px 8px;
    }

    .qr-img {
      width: 54px;
      height: 54px;
      display: block;
      border: 1px solid #d4d4d8;
      background: #ffffff;
      border-radius: 4px;
      padding: 1px;
    }

    .qr-label {
      font-size: 8.5px;
      font-weight: 800;
      color: #18181b;
      line-height: 1.2;
      text-transform: uppercase;
    }

    .qr-sub {
      font-size: 8px;
      color: #71717a;
      margin-top: 1px;
    }

    /* 2. Metadata Strip */
    .meta-strip {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #f4f4f5;
      border: 1px solid #e4e4e7;
      padding: 3.5px 8px;
      border-radius: 3px;
      font-size: 8.5px;
      color: #27272a;
      margin: 4px 0;
    }

    /* Section Headings */
    .section-header {
      background: #f4f4f5;
      border-left: 3px solid #18181b;
      padding: 2.5px 7px;
      font-size: 9px;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0.3px;
      color: #09090b;
      margin: 4px 0 2.5px 0;
    }

    /* 3. Property Grid */
    .params-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 6px;
      border: 1px solid #e4e4e7;
      background: #fafafa;
      padding: 5px 8px;
      border-radius: 4px;
      font-size: 9px;
    }

    .param-col {
      display: flex;
      flex-direction: column;
      gap: 1.5px;
    }

    .param-lbl {
      color: #71717a;
      font-size: 8px;
      text-transform: uppercase;
      font-weight: 700;
    }

    .param-val {
      font-weight: 800;
      color: #09090b;
    }

    /* Area Conversion Strip */
    .area-strip {
      display: flex;
      justify-content: space-between;
      background: #fafafa;
      border: 1px solid #e4e4e7;
      border-radius: 3px;
      padding: 3px 8px;
      margin-top: 3px;
      font-size: 8.5px;
      color: #3f3f46;
      font-family: monospace;
    }

    /* 4. Section 47-A Valuation Benchmark */
    .val-benchmark {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px;
      background: #f8fafc;
      border: 1px solid #cbd5e1;
      padding: 5px 8px;
      border-radius: 4px;
      margin: 4px 0;
    }

    /* 5. Statutory Dues Table */
    .fee-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 3px;
      border: 1px solid #71717a;
      font-size: 9.5px;
    }

    .fee-table th, .fee-table td {
      padding: 4px 6px;
      border: 1px solid #d4d4d8;
      text-align: left;
    }

    .fee-table th {
      background: #f4f4f5;
      font-weight: 800;
      color: #09090b;
      font-size: 9px;
      text-transform: uppercase;
    }

    .fee-table .total-row td {
      background: #f4f4f5;
      font-weight: 900;
      font-size: 11.5px;
      border-top: 2px solid #09090b;
    }

    /* 6. Total in Words Box */
    .total-box {
      margin-top: 4px;
      background: #fffbeb;
      border: 1px solid #fcd34d;
      padding: 4px 8px;
      border-radius: 4px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 9.5px;
    }

    /* 7. Legal Disclaimer & Caveats */
    .disclaimer-box {
      margin-top: 4px;
      border: 1px solid #e4e4e7;
      background: #fafafa;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 8px;
      color: #3f3f46;
      line-height: 1.35;
    }

    /* 8. 3-Column Formal Endorsement & Signatures */
    .sign-row {
      margin-top: 6px;
      padding-top: 6px;
      border-top: 1.5px solid #71717a;
      display: flex;
      justify-content: space-between;
      gap: 12px;
    }

    .sign-col {
      width: 32%;
      text-align: center;
      display: flex;
      flex-direction: column;
      justify-content: flex-end;
    }

    .sign-box-thumb {
      height: 38px;
      border: 1px dashed #71717a;
      border-radius: 3px;
      margin-bottom: 3px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 7.5px;
      color: #71717a;
      background: #fafafa;
      font-weight: 600;
    }

    .sign-line {
      height: 30px;
      border-bottom: 1px dashed #71717a;
      margin-bottom: 3px;
    }

    /* 9. Single Page Footer */
    .footer-bar {
      margin-top: 4px;
      padding-top: 3.5px;
      border-top: 1px solid #e4e4e7;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 8px;
      color: #52525b;
    }

    /* STRICT SINGLE A4 PRINT STYLES */
    @media print {
      @page {
        size: A4 portrait;
        margin: 5mm 7mm 5mm 7mm;
      }
      html, body {
        background: #ffffff !important;
        padding: 0 !important;
        margin: 0 !important;
        width: 100% !important;
        height: 100% !important;
        max-height: 297mm !important;
        overflow: hidden !important;
      }
      .top-action-bar {
        display: none !important;
      }
      .paper-container {
        border: 1px solid #71717a !important;
        box-shadow: none !important;
        padding: 5mm 7mm !important;
        margin: 0 !important;
        width: 100% !important;
        max-width: 100% !important;
        height: 284mm !important;
        min-height: 284mm !important;
        max-height: 284mm !important;
        overflow: hidden !important;
        page-break-inside: avoid !important;
        page-break-after: avoid !important;
        break-inside: avoid !important;
        break-after: avoid !important;
      }
    }
  </style>
</head>
<body>
  <div class="top-action-bar">
    <div>
      <strong>Advocate A. Soofiyan — Kanpur</strong> &bull; Verified Single-Sheet A4 Calculation Slip
    </div>
    <div>
      <button class="btn-print" onclick="window.print()">🖨️ Print / Save as PDF (Single A4)</button>
    </div>
  </div>

  <div class="paper-container">
    <!-- Block 1: Letterhead & QR Code -->
    <div>
      <div class="header-row">
        <div class="chamber-brand">
          <div class="chamber-title">${t.printOfficeTitle}</div>
          <div class="chamber-sub">${t.printOfficeSub}</div>
          <div class="chamber-court">
            Kanpur Bar Association &bull; Civil &amp; Revenue Court &bull; Sub-Registrar Complex, Kanpur Nagar &amp; Dehat
          </div>
          <div>
            <span class="brand-pill">
              <span>🌐 soofiyan.com</span>
              <span style="font-weight: normal; opacity: 0.85;">| Official Legal Assessment Portal</span>
            </span>
          </div>
        </div>

        <!-- Right: High-Resolution QR Code for instant PDF / report verification -->
        <div class="qr-container">
          ${
            qrDataUrl
              ? `<img src="${qrDataUrl}" alt="Scan QR Code to view PDF report on soofiyan.com" class="qr-img" />`
              : `<div style="width: 54px; height: 54px; border: 1px dashed #a1a1aa; display: flex; align-items: center; justify-content: center; font-size: 7.5px; color: #71717a; text-align: center;">QR Code</div>`
          }
          <div style="text-align: left;">
            <div class="qr-label">Scan to View</div>
            <div class="qr-label" style="color: #b45309;">soofiyan.com</div>
            <div class="qr-sub">Digital PDF Report</div>
            <div class="qr-sub" style="font-family: monospace; font-size: 7.5px; color: #3f3f46; font-weight: 700;">${refCode}</div>
          </div>
        </div>
      </div>

      <!-- Block 2: Metadata Strip -->
      <div class="meta-strip">
        <div><strong>Report Ref:</strong> <span style="font-family: monospace; font-weight: 700;">${refCode}</span></div>
        <div><strong>${t.printGeneratedDate}:</strong> ${printDateStr}, ${printTimeStr}</div>
        <div><strong>Revenue Standard:</strong> Awadh / Doab (22,500 sq ft = 1 Pucca Bigha)</div>
        <div><strong>Jurisdiction:</strong> Kanpur (U.P.)</div>
      </div>
    </div>

    <!-- Block 3: Property Particulars & Area Equivalence -->
    <div>
      <div class="section-header">${t.printPropertyDetailsTitle}</div>
      <div class="params-grid">
        <div class="param-col">
          <span class="param-lbl">${t.localitySummary}</span>
          <span class="param-val" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${input.localityName || 'Kanpur Nagar'}">${input.localityName || 'Kanpur Urban / Rural'}</span>
        </div>
        <div class="param-col">
          <span class="param-lbl">${t.propertyType}</span>
          <span class="param-val">${isPlot ? t.plotOption : t.agriculturalOption}</span>
        </div>
        <div class="param-col">
          <span class="param-lbl">${t.areaValue}</span>
          <span class="param-val" style="font-family: monospace;">${dimensionText}</span>
        </div>
        <div class="param-col">
          <span class="param-lbl">${t.buyerCategory}</span>
          <span class="param-val">${buyerCategoryLabel}</span>
        </div>
      </div>

      <!-- Area Equivalence Strip -->
      <div class="area-strip">
        <span><strong>Sq. Metres:</strong> ${formatNumber(results.convertedAreaSqM, 2)} m²</span>
        <span><strong>Sq. Feet:</strong> ${formatNumber(sqFeet, 0)} ft²</span>
        <span><strong>Biswa:</strong> ${formatNumber(biswa, 2)}</span>
        <span><strong>Pucca Bigha:</strong> ${formatNumber(puccaBigha, 3)}</span>
        <span><strong>Hectares:</strong> ${formatNumber(results.convertedAreaHectares, 4)} ha</span>
        <span><strong>Acres:</strong> ${formatNumber(acres, 3)} ac</span>
      </div>
    </div>

    <!-- Block 4: Section 47-A Valuation Benchmark -->
    <div>
      <div class="section-header">${language === 'hi' ? 'धारा 47-A राजस्व मूल्यांकन बेंचमार्क' : 'Section 47-A Valuation Benchmark'}</div>
      <div class="val-benchmark">
        <div>
          <div style="font-size: 8px; color: #64748b; text-transform: uppercase; font-weight: 700;">Circle Rate Assessment</div>
          <div style="font-size: 11px; font-weight: 800; font-family: monospace; color: #0f172a;">${formatINR(results.circleRateValue)}</div>
          <div style="font-size: 7.5px; color: #64748b;">@ ₹${formatNumber(input.circleRate || 0, 0)} / ${isPlot ? 'sq. m' : 'hectare'}</div>
        </div>
        <div>
          <div style="font-size: 8px; color: #64748b; text-transform: uppercase; font-weight: 700;">Declared Consideration</div>
          <div style="font-size: 11px; font-weight: 800; font-family: monospace; color: #0f172a;">
            ${input.declaredPrice ? formatINR(Number(input.declaredPrice)) : 'Not Declared (₹0)'}
          </div>
          <div style="font-size: 7.5px; color: #64748b;">Agreed sale deed price</div>
        </div>
        <div style="background: #f1f5f9; border-left: 3px solid #0284c7; padding-left: 8px;">
          <div style="font-size: 8px; color: #0369a1; text-transform: uppercase; font-weight: 800;">Sec 47-A Taxable Base</div>
          <div style="font-size: 11.5px; font-weight: 900; font-family: monospace; color: #0c4a6e;">${formatINR(results.propertyValue)}</div>
          <div style="font-size: 7.5px; color: #0369a1; font-weight: 700;">Higher of Circle Rate vs Declared</div>
        </div>
      </div>
    </div>

    <!-- Block 5: Statutory Dues Table & Purchaser Expenses -->
    <div>
      <div class="section-header">${t.printFeeTableTitle}</div>
      <table class="fee-table">
        <thead>
          <tr>
            <th style="width: 24px; text-align: center;">#</th>
            <th>${t.printParticulars}</th>
            <th style="text-align: right; width: 135px;">Taxable Base</th>
            <th style="text-align: right; width: 135px;">${t.printCalculatedDues}</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="text-align: center; font-family: monospace;">1</td>
            <td>
              <strong>${t.stampDuty}</strong>
              <div style="font-size: 8px; color: #71717a;">${t.stampDutyRateText}</div>
            </td>
            <td style="text-align: right; font-family: monospace;">${formatINR(results.propertyValue)}</td>
            <td style="text-align: right; font-weight: bold; font-family: monospace;">${formatINR(results.stampDutyAmount)}</td>
          </tr>
          <tr>
            <td style="text-align: center; font-family: monospace;">2</td>
            <td>
              <strong>${t.registrationFee}</strong>
              <div style="font-size: 8px; color: #71717a;">${t.registrationFeeText}</div>
            </td>
            <td style="text-align: right; font-family: monospace;">${formatINR(results.propertyValue)}</td>
            <td style="text-align: right; font-weight: bold; font-family: monospace;">${formatINR(results.registrationFeeAmount)}</td>
          </tr>
          <tr style="background: #fbfbfb; font-weight: 700; font-size: 9.5px;">
            <td colspan="3" style="text-align: right; padding-right: 8px; color: #3f3f46;">${t.govtDuesSubtotal}:</td>
            <td style="text-align: right; font-family: monospace; font-weight: 800; color: #18181b;">${formatINR(results.governmentDues || (results.stampDutyAmount + results.registrationFeeAmount))}</td>
          </tr>

          ${results.totalExpenses > 0 ? `
          <!-- 2-Column Incidental Expenses Row -->
          <tr style="background: #fffbeb;">
            <td style="text-align: center; font-family: monospace; font-size: 8.5px; vertical-align: top; padding-top: 4px;">3-8</td>
            <td colspan="2" style="padding: 4px 6px;">
              <div style="font-weight: 800; color: #92400e; font-size: 8.5px; text-transform: uppercase; margin-bottom: 2px;">
                ${t.expensesSectionTitle} (Incidental, Typing, Audit &amp; Legal Documentation)
              </div>
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5px 10px; font-size: 8px; color: #78350f;">
                <div>• ${t.expTypingOnline}: <strong>${formatINR(results.itemizedExpenses?.typingOnline ?? 1200)}</strong></div>
                <div>• ${t.expAudit}: <strong>${formatINR(results.itemizedExpenses?.audit ?? 1000)}</strong></div>
                <div>• ${t.expAdvocateFee}: <strong>${formatINR(results.itemizedExpenses?.advocateFee ?? 1500)}</strong></div>
                <div>• ${t.expGpsPhoto}: <strong>${formatINR(results.itemizedExpenses?.gpsPhoto ?? 100)}</strong></div>
                <div>• ${t.expCertification}: <strong>${formatINR(results.itemizedExpenses?.certification ?? 1500)}</strong></div>
                <div>• ${t.expNaqshaNazari}: <strong>${formatINR(results.itemizedExpenses?.naqshaNazari ?? 1000)}</strong></div>
              </div>
            </td>
            <td style="text-align: right; font-family: monospace; font-weight: 800; color: #92400e; vertical-align: bottom; font-size: 10px;">
              ${formatINR(results.totalExpenses)}
            </td>
          </tr>
          ` : ''}

          <!-- Grand Total Row -->
          <tr class="total-row">
            <td colspan="2">
              <div style="text-transform: uppercase; font-size: 11px;">${results.totalExpenses > 0 ? t.grandTotalPayable : t.totalPayable}</div>
              <div style="font-size: 8px; font-weight: normal; color: #71717a;">${results.totalExpenses > 0 ? t.grandTotalSubtext : t.totalPayableSubtext}</div>
            </td>
            <td style="text-align: right; font-family: monospace; color: #71717a;">—</td>
            <td style="text-align: right; font-size: 13.5px; font-weight: 900; font-family: monospace; color: #09090b;">${formatINR(results.grandTotal || results.totalPayable)}</td>
          </tr>
        </tbody>
      </table>

      <!-- Total In Words Box -->
      <div class="total-box">
        <div>
          <span style="font-weight: 700; color: #3f3f46;">${t.printTotalPayableWords}: </span>
          <span style="font-style: italic; font-weight: 800; color: #09090b;">${formatIndianCurrencyWords(results.grandTotal || results.totalPayable, language)}</span>
        </div>
        <div style="font-weight: 800; color: #92400e; font-family: monospace; font-size: 10px;">${formatLakhCrore(results.grandTotal || results.totalPayable, language)}</div>
      </div>

      ${results.femaleConcessionApplied ? `
      <div style="margin-top: 3px; padding: 2.5px 6px; background: #ecfdf5; border: 1px solid #6ee7b7; border-radius: 3px; font-size: 8px; color: #065f46; font-weight: 700;">
        &check; ${results.stampDutyRate === 0.06 ? t.femaleBenefitBadge : t.jointFemaleBenefitBadge}
      </div>` : ''}
    </div>

    <!-- Block 6: Legal Caveat & Statutory Rules -->
    <div>
      <div class="disclaimer-box">
        <div style="font-weight: 800; color: #18181b; text-transform: uppercase; margin-bottom: 1.5px; font-size: 8px;">
          ${t.printLegalNoticeTitle} (Section 47-A, Indian Stamp Act 1899 &amp; UP Stamp Rules)
        </div>
        <div>${t.disclaimerText} All statutory stamp dues rounded up to whole rupee (Math.ceil). Official e-stamping and deed verification available at igrsup.gov.in.</div>
      </div>
    </div>

    <!-- Block 7: Official Endorsements, Seals & Signatures -->
    <div>
      <div class="sign-row">
        <!-- Col 1: Advocate Seal & Sign -->
        <div class="sign-col">
          <div class="sign-line"></div>
          <div style="font-weight: 800; font-size: 9px; color: #09090b;">${t.printSignAdvocate}</div>
          <div style="font-size: 7.5px; color: #52525b;">Advocate A. Soofiyan &bull; soofiyan.com</div>
          <div style="font-size: 7px; color: #71717a;">Counsel for Purchaser &amp; Legal Scrutiny</div>
        </div>

        <!-- Col 2: Purchaser Sign & Left Thumb Impression -->
        <div class="sign-col">
          <div class="sign-box-thumb">
            Purchaser Signature &amp; Left Thumb Impression (LTI)
          </div>
          <div style="font-weight: 800; font-size: 9px; color: #09090b;">${t.printSignClient}</div>
          <div style="font-size: 7.5px; color: #52525b;">Purchaser / Executant Endorsement</div>
        </div>

        <!-- Col 3: Sub-Registrar Office Kanpur -->
        <div class="sign-col">
          <div class="sign-line"></div>
          <div style="font-weight: 800; font-size: 9px; color: #09090b;">Sub-Registrar Office Endorsement</div>
          <div style="font-size: 7.5px; color: #52525b;">Registry &amp; SRO Filing Complex, Kanpur</div>
          <div style="font-size: 7px; color: #71717a;">Official Presentation &amp; Entry Stamp</div>
        </div>
      </div>

      <!-- Block 8: Watermark & Verification Footer -->
      <div class="footer-bar">
        <span>🌐 Digitally authenticated via <strong>soofiyan.com</strong></span>
        <span>Advocate A. Soofiyan &bull; Kanpur Bar Association</span>
        <span>Strict Single-Sheet Assessment &bull; <strong>Page 1 of 1</strong></span>
      </div>
    </div>
  </div>

  <script>
    window.addEventListener('load', function() {
      setTimeout(function() {
        try {
          window.print();
        } catch(e) {
          console.log('Print error:', e);
        }
      }, 400);
    });
  </script>
</body>
</html>`;
}

