import QRCode from 'qrcode';
import { CalculationInput, PropertyType } from '../types';

/**
 * Builds the canonical shareable URL for the report that will be encoded into the QR code.
 * Scanning this URL opens ONLY the PDF report of the calculation slip, not the full web app.
 */
export function buildReportShareUrl(
  input: CalculationInput,
  propertyType: PropertyType
): string {
  let origin = 'https://soofiyan.com';
  let pathname = '/';
  if (typeof window !== 'undefined' && window.location) {
    if (window.location.origin && window.location.origin !== 'null') {
      origin = window.location.origin;
    }
    pathname = window.location.pathname || '/';
  }

  const url = new URL(pathname, origin);
  url.searchParams.set('view', 'pdf');
  url.searchParams.set('pt', propertyType);
  if (input.areaValue) url.searchParams.set('area', String(input.areaValue));
  if (input.areaUnit) url.searchParams.set('unit', input.areaUnit);
  if (input.circleRate) url.searchParams.set('rate', String(input.circleRate));
  if (input.declaredPrice) url.searchParams.set('dec', String(input.declaredPrice));
  if (input.buyerCategory) url.searchParams.set('cat', input.buyerCategory);
  if (input.registrationFeePercent) url.searchParams.set('reg', String(input.registrationFeePercent));
  if (input.localityName) url.searchParams.set('loc', input.localityName);
  if (input.includeExpenses !== undefined) url.searchParams.set('exp', input.includeExpenses ? '1' : '0');
  if (input.dimensionCalcEnabled) {
    url.searchParams.set('dim', '1');
    if (input.dimensionLength) url.searchParams.set('dimL', String(input.dimensionLength));
    if (input.dimensionHeight) url.searchParams.set('dimH', String(input.dimensionHeight));
    if (input.dimensionUnit) url.searchParams.set('dimU', input.dimensionUnit);
  }

  return url.toString();
}

/**
 * Asynchronously generates a Base64 Data URL for the QR code image
 */
export async function generateQrDataUrl(text: string): Promise<string> {
  try {
    return await QRCode.toDataURL(text, {
      margin: 1,
      width: 130,
      color: {
        dark: '#111827', // Crisp dark gray / black
        light: '#ffffff', // Pure white
      },
      errorCorrectionLevel: 'M',
    });
  } catch (err) {
    console.warn('QR Code generation error:', err);
    // Return a 1x1 transparent png or empty string on failure
    return '';
  }
}
